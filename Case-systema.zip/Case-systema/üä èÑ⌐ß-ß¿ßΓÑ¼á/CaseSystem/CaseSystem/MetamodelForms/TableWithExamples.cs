﻿using CaseSystem.Model;
using CaseSystem.Model.PartialClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CaseSystem.MetamodelForms
{
    public partial class TableWithExamples : Form
    {
        Table table;
        Model1Container db;
        Form1 form;
        List<Model.Attribute> attributes;
        List<Model.Example> examples;
        bool nowadd=false;
        bool edit = false;
        bool nowedit = false;

        public TableWithExamples(Form1 form, Table table, ref Model1Container db)
        {
            InitializeComponent();
            this.table = table;
            this.db = db;
            this.form = form;
            form.Enabled = false;
            this.Name = table.TableName;
            FillTable();
            this.Text = "Просмотр элементов таблицы " + table.TableName;
        }

        public void FillTable()
        {
            attributes = PTable.GetAttributes(table.IDTable, ref db);
            examples = PTable.GetExamples(table.IDTable, ref db);
            Values[,] mas = new Values[examples.Count, attributes.Count];
            for (int i = 0; i < examples.Count; i++)
                for (int j = 0; j < attributes.Count; j++)
                {
                    Int64 ex = examples[i].IDExample;
                    Int64 atr = attributes[j].IDAttribute;
                    mas[i, j] = (from x in db.ValuesSet where x.Example.IDExample == ex && x.Attribute.IDAttribute == atr select x).First();
                }
            dgvTable.ColumnCount = attributes.Count() + 1;
            dgvTable.RowCount = examples.Count() + 1;
            for (int i = 1; i <= attributes.Count; i++)
            {
                dgvTable.Columns[i].HeaderText = attributes[i - 1].AttributeName;
                if (attributes[i - 1].IsKey) dgvTable.Columns[i].HeaderText = attributes[i - 1].AttributeName + "*";
                dgvTable.Rows[0].Cells[i].Value = attributes[i - 1].IDAttribute;
            }
            for (int i = 1; i <= examples.Count; i++)
            {
                dgvTable.Rows[i].Cells[0].Value = examples[i - 1].IDExample;
            }

            for (int i = 1; i <= examples.Count; i++)
                for (int j = 1; j <= attributes.Count; j++)
                {
                    dgvTable.Rows[i].Cells[j].Value = mas[i - 1, j - 1].Content;
                }
            if (examples.Count > 0) dgvTable.Rows[0].Visible = false;
            dgvTable.Columns[0].Visible = false;
            dgvTable.Rows[0].ReadOnly = true;
            dgvTable.Update();
        }

        private void TableWithExamples_FormClosing(object sender, FormClosingEventArgs e)
        {
            form.Enabled = true;
        }

        private void TableWithExamples_Load(object sender, EventArgs e)
        {            
            if (examples.Count>0) edit = true;
        }

        private void dgvTable_NewRowNeeded(object sender, DataGridViewRowEventArgs e)
        {
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!nowadd)
            {
                nowadd = true;
                dgvTable.Rows.Add();
                dgvTable.Rows[dgvTable.Rows.Count - 1].Selected = true;
                dgvTable.CurrentCell = dgvTable.Rows[dgvTable.Rows.Count - 1].Cells[1];
                btnAdd.Enabled = false;
                btnDelete.Enabled = false;
                for (int i=1; i <= attributes.Count; i++)
                {
                    dgvTable.Rows[dgvTable.Rows.Count - 1].Cells[i].Value = attributes[i - 1].InitialValue;
                }
            }
            else
            {
                MessageBox.Show("Сначала добавьте предыдущий элемент");
            }
        }

        public List<Model.Values> GetValues()
        {
            List<Model.Values> list = new List<Model.Values>();
            for (int i = 1; i <= attributes.Count; i++)
            {
                string value = (string)dgvTable.SelectedRows[0].Cells[i].Value;
                Model.Attribute a = db.AttributeSet.Find(dgvTable.Rows[0].Cells[i].Value);
                Values v = new Values
                {
                    Content = value,
                    Attribute = a,
                };
                list.Add(v);
            }
            return list;
        }

        public void Add()
        {
            //получаем список значений
            List<Model.Values> list = GetValues();
            //пытаемся добавить
            string message;
            if (!PExample.Add(list, table, out message, ref db))
                MessageBox.Show(message);
            else
            {
                btnAdd.Enabled = true;
                btnDelete.Enabled = true;                
                FillTable();
                nowadd = false;
                edit = true;
            }
        }

        private void dgvTable_Click(object sender, EventArgs e)
        {
            if ((nowadd)&&(!dgvTable.Rows[dgvTable.Rows.Count - 1].Selected))
            {                
                dgvTable.Rows[dgvTable.Rows.Count - 1].Selected = true;
                dgvTable.CurrentCell = dgvTable.Rows[dgvTable.Rows.Count - 1].Cells[1];
                Add();
            }
            nowedit = false;
        }

        private void dgvTable_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (edit && !nowadd && !nowedit)
            {
                nowedit = true;
                //получаем список значений
                List<Model.Values> list = GetValues();
                //получаем список ключевых полей
                string keys = "";
                for (int i = 1; i <= attributes.Count; i++)
                {
                    if (attributes[i-1].IsKey)
                    keys=keys+(string)dgvTable.SelectedRows[0].Cells[i].Value;                   
                }
                Example ex = db.ExampleSet.Find(dgvTable.SelectedRows[0].Cells[0].Value);
                if (PExample.CheckID(keys, ref db, ex))
                {
                    string m;
                    if (!PExample.Change((long)dgvTable.SelectedRows[0].Cells[0].Value, list, out m, ref db))
                        MessageBox.Show(m);
                }
                else MessageBox.Show("Элемент с таким ключом существует");
                FillTable();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (edit && !nowadd && !nowedit)
            {
                nowadd = true;
                if (!PExample.Delete((long)dgvTable.SelectedRows[0].Cells[0].Value, ref db))
                    MessageBox.Show("На данный объект существует ссылка с жесткой связью. Перед тем, как удалить данный объект, удалите все ссылающиеся на него элементы сжесткой связью!");
                else
                    FillTable();
                nowadd = false;
                edit = true;
            }
        }
    }
}
