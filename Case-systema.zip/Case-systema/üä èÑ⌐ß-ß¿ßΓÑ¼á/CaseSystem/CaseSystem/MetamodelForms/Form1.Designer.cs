﻿namespace CaseSystem.MetamodelForms
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvProjects = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnNewProject = new System.Windows.Forms.Button();
            this.dgvTables = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.btnOpenConstructor = new System.Windows.Forms.Button();
            this.btnGoToRequests = new System.Windows.Forms.Button();
            this.btnCreateTable = new System.Windows.Forms.Button();
            this.btnDeleteTable = new System.Windows.Forms.Button();
            this.btnExamples = new System.Windows.Forms.Button();
            this.btnCreateForm = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProjects)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTables)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvProjects
            // 
            this.dgvProjects.AllowUserToAddRows = false;
            this.dgvProjects.AllowUserToDeleteRows = false;
            this.dgvProjects.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvProjects.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProjects.Location = new System.Drawing.Point(18, 67);
            this.dgvProjects.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgvProjects.MultiSelect = false;
            this.dgvProjects.Name = "dgvProjects";
            this.dgvProjects.ReadOnly = true;
            this.dgvProjects.RowTemplate.Height = 24;
            this.dgvProjects.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProjects.Size = new System.Drawing.Size(180, 328);
            this.dgvProjects.TabIndex = 0;
            this.dgvProjects.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProjects_CellContentClick);
            this.dgvProjects.Click += new System.EventHandler(this.dgvProjects_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 32);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Проекты:";
            // 
            // btnNewProject
            // 
            this.btnNewProject.Location = new System.Drawing.Point(105, 25);
            this.btnNewProject.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnNewProject.Name = "btnNewProject";
            this.btnNewProject.Size = new System.Drawing.Size(93, 28);
            this.btnNewProject.TabIndex = 2;
            this.btnNewProject.Text = "Новый проект";
            this.btnNewProject.UseVisualStyleBackColor = true;
            this.btnNewProject.Click += new System.EventHandler(this.btnNewProject_Click);
            // 
            // dgvTables
            // 
            this.dgvTables.AllowUserToAddRows = false;
            this.dgvTables.AllowUserToDeleteRows = false;
            this.dgvTables.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTables.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTables.Location = new System.Drawing.Point(242, 103);
            this.dgvTables.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgvTables.MultiSelect = false;
            this.dgvTables.Name = "dgvTables";
            this.dgvTables.ReadOnly = true;
            this.dgvTables.RowTemplate.Height = 24;
            this.dgvTables.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTables.Size = new System.Drawing.Size(180, 292);
            this.dgvTables.TabIndex = 3;
            this.dgvTables.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTables_CellContentClick);
            this.dgvTables.Click += new System.EventHandler(this.dgvTables_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(240, 67);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Таблицы:";
            // 
            // btnOpenConstructor
            // 
            this.btnOpenConstructor.Location = new System.Drawing.Point(442, 228);
            this.btnOpenConstructor.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnOpenConstructor.Name = "btnOpenConstructor";
            this.btnOpenConstructor.Size = new System.Drawing.Size(86, 39);
            this.btnOpenConstructor.TabIndex = 7;
            this.btnOpenConstructor.Text = "Открыть в конструкторе";
            this.btnOpenConstructor.UseVisualStyleBackColor = true;
            this.btnOpenConstructor.Click += new System.EventHandler(this.btnOpenConstructor_Click);
            // 
            // btnGoToRequests
            // 
            this.btnGoToRequests.Location = new System.Drawing.Point(442, 18);
            this.btnGoToRequests.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnGoToRequests.Name = "btnGoToRequests";
            this.btnGoToRequests.Size = new System.Drawing.Size(86, 36);
            this.btnGoToRequests.TabIndex = 12;
            this.btnGoToRequests.Text = "Запросы";
            this.btnGoToRequests.UseVisualStyleBackColor = true;
            this.btnGoToRequests.Click += new System.EventHandler(this.btnGoToRequests_Click);
            // 
            // btnCreateTable
            // 
            this.btnCreateTable.Location = new System.Drawing.Point(442, 103);
            this.btnCreateTable.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCreateTable.Name = "btnCreateTable";
            this.btnCreateTable.Size = new System.Drawing.Size(86, 39);
            this.btnCreateTable.TabIndex = 13;
            this.btnCreateTable.Text = "Новая таблица";
            this.btnCreateTable.UseVisualStyleBackColor = true;
            this.btnCreateTable.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDeleteTable
            // 
            this.btnDeleteTable.Location = new System.Drawing.Point(442, 165);
            this.btnDeleteTable.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnDeleteTable.Name = "btnDeleteTable";
            this.btnDeleteTable.Size = new System.Drawing.Size(86, 39);
            this.btnDeleteTable.TabIndex = 14;
            this.btnDeleteTable.Text = "Удалить";
            this.btnDeleteTable.UseVisualStyleBackColor = true;
            this.btnDeleteTable.Click += new System.EventHandler(this.btnDeleteTable_Click);
            // 
            // btnExamples
            // 
            this.btnExamples.Location = new System.Drawing.Point(442, 292);
            this.btnExamples.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnExamples.Name = "btnExamples";
            this.btnExamples.Size = new System.Drawing.Size(86, 39);
            this.btnExamples.TabIndex = 15;
            this.btnExamples.Text = "Просмотр элементов";
            this.btnExamples.UseVisualStyleBackColor = true;
            this.btnExamples.Click += new System.EventHandler(this.btnExamples_Click);
            // 
            // btnCreateForm
            // 
            this.btnCreateForm.Location = new System.Drawing.Point(442, 356);
            this.btnCreateForm.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnCreateForm.Name = "btnCreateForm";
            this.btnCreateForm.Size = new System.Drawing.Size(86, 39);
            this.btnCreateForm.TabIndex = 16;
            this.btnCreateForm.Text = "Открыть форму";
            this.btnCreateForm.UseVisualStyleBackColor = true;
            this.btnCreateForm.Click += new System.EventHandler(this.button4_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(575, 430);
            this.Controls.Add(this.btnCreateForm);
            this.Controls.Add(this.btnExamples);
            this.Controls.Add(this.btnDeleteTable);
            this.Controls.Add(this.btnCreateTable);
            this.Controls.Add(this.btnGoToRequests);
            this.Controls.Add(this.btnOpenConstructor);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvTables);
            this.Controls.Add(this.btnNewProject);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvProjects);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximumSize = new System.Drawing.Size(591, 469);
            this.MinimumSize = new System.Drawing.Size(591, 469);
            this.Name = "Form1";
            this.Text = "Case-система";
            ((System.ComponentModel.ISupportInitialize)(this.dgvProjects)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTables)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvProjects;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnNewProject;
        private System.Windows.Forms.DataGridView dgvTables;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnOpenConstructor;
        private System.Windows.Forms.Button btnGoToRequests;
        private System.Windows.Forms.Button btnCreateTable;
        private System.Windows.Forms.Button btnDeleteTable;
        private System.Windows.Forms.Button btnExamples;
        private System.Windows.Forms.Button btnCreateForm;
    }
}

