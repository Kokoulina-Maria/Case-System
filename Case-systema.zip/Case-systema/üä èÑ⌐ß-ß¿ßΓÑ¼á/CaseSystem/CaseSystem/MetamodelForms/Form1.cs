﻿using CaseSystem.MetamodelForms;
using CaseSystem.Model;
using CaseSystem.Model.PartialClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CaseSystem.MetamodelForms
{
    public partial class Form1 : Form
    {
        public Model1Container db;
        public Project CurrentProject=null;
        public Form1()
        {
            InitializeComponent();
            db = new Model1Container();
            if (db.ProjectSet.Count() > 0)
            {
                CurrentProject = db.ProjectSet.First();
                UpdateProject();
            }
        }

        public void ProjectsTables()
        {
            if (db.ProjectSet.Find(CurrentProject.IDProject).Table.Count() > 0)
            {
                dgvTables.DataSource = (from t in db.ProjectSet.Find(CurrentProject.IDProject).Table select new { t.IDTable, t.TableName }).ToList();
                dgvTables.Columns[0].Visible = false;
                dgvTables.Columns[1].HeaderText = "Название таблицы";
                dgvTables.Update();
            }
            else dgvTables.DataSource = null;
            dgvTables.Update();
        }

        private void btnNewProject_Click(object sender, EventArgs e)
        {
            AddProject form = new AddProject(ref db, this);
            form.Show();            

        }

        public void UpdateProject()
        {
            if (db.ProjectSet.Count() > 0)
            {
                dgvProjects.DataSource = (from p in db.ProjectSet select new { p.IDProject, p.ProjectName }).ToList();
                dgvProjects.Columns[0].Visible = false;
                dgvProjects.Columns[1].HeaderText = "Название проекта";
            }
            dgvProjects.Update();
            ProjectsTables();
        }

        private void dgvProjects_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Forms f = new Forms(db.TableSet.Find((int)dgvTables.SelectedRows[0].Cells[0].Value), ref db);
            f.Show();
        }

        /// <summary>
        /// Добавление таблицы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            AddTable form = new AddTable(ref db, this);
            form.Show();
        }

        private void btnDeleteTable_Click(object sender, EventArgs e)
        {
            if (dgvTables.SelectedRows.Count == 1)
            {
                DialogResult r = MessageBox.Show("Все данные, содержащиеся в этой таблице будут потеряны. Вы уверены, что хотите удалить таблицу?", "Удаление таблицы", MessageBoxButtons.YesNo);
                if (r == DialogResult.Yes)
                {
                    if (!PTable.Delete((int)dgvTables.SelectedRows[0].Cells[0].Value, ref db))
                    {
                        MessageBox.Show("Нельзя удалить данную таблицу, так как не нее ссылается другая таблица. Сначала удалите связь. Для этого следует удалить соответсвующий атрибут таблицы, ссылающейся на данную.");
                    }
                    else
                    {
                        ProjectsTables();
                    }
                }
            }
        }

        private void dgvTables_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void btnOpenConstructor_Click(object sender, EventArgs e)
        {
            TableConstructor form = new TableConstructor(this, db.TableSet.Find((int)dgvTables.SelectedRows[0].Cells[0].Value), ref db);
            form.Show();
        }

        private void dgvProjects_Click(object sender, EventArgs e)
        {
            if (db.ProjectSet.Count() > 0)
                CurrentProject = db.ProjectSet.Find(dgvProjects.SelectedRows[0].Cells[0].Value);
            ProjectsTables();
        }

        private void dgvTables_Click(object sender, EventArgs e)
        {

        }

        private void btnExamples_Click(object sender, EventArgs e)
        {
            TableWithExamples form = new TableWithExamples(this, db.TableSet.Find((int)dgvTables.SelectedRows[0].Cells[0].Value), ref db);
            form.Show();
        }

        private void btnGoToRequests_Click(object sender, EventArgs e)
        {
            RequestsForm rf = new RequestsForm(ref db, CurrentProject);
            rf.ShowDialog();
        }
    }
}
