﻿using CaseSystem.Model;
using CaseSystem.Model.PartialClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CaseSystem.MetamodelForms
{
    public partial class AddConnection : Form
    {
        Model1Container db;
        TableConstructor form;
        bool canBeClosed = false;
        Table t;
        bool isHurd=false;
        public AddConnection(TableConstructor form, ref Model1Container db, Project p)
        {
            InitializeComponent();
            this.form = form;
            this.db = db;
            this.form.Enabled = false;
            this.db = db;
            comboBox1.DataSource = (from d in db.TableSet where d.Project.IDProject == p.IDProject select d).ToList();
            comboBox1.DisplayMember = "TableName";
            comboBox1.Update();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != "")
            {
                Table x = db.TableSet.Find(((Table)comboBox1.SelectedValue).IDTable);
                string m;
                if (PConnection.Check(x, ref db, out m))
                {
                    t = x;
                    isHurd = checkBox1.Checked;
                    form.Enabled = true;
                    canBeClosed = true;
                    this.Close();
                }
                else MessageBox.Show(m);
            }
            else MessageBox.Show("Выберите таблицу!");
        }

        private void AddConnection_FormClosing(object sender, FormClosingEventArgs e)
        {
            form.AfterAddConnection(canBeClosed, t, isHurd);
        }
    }
}
