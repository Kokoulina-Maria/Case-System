﻿using CaseSystem.Model;
using CaseSystem.Model.PartialClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CaseSystem.MetamodelForms
{
    public partial class AddTable : Form
    {
        Model1Container db;
        Form1 form;
        Project p;
        public AddTable(ref Model1Container db, Form1 form)
        {
            InitializeComponent();
            this.form = form;
            p = form.CurrentProject;
            this.form.Enabled = false;
            this.db = db;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string m;
            if (!PTable.Add(p, textBox1.Text, ref db, out m))
            {
                MessageBox.Show(m);
            }
            else
            {
                form.Enabled = true;
                form.ProjectsTables();
                this.Dispose();
                this.Close();
            }
        }
    }
}
