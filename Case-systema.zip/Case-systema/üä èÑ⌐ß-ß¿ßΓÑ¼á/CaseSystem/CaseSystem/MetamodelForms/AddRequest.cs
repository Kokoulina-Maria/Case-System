﻿using CaseSystem.MetamodelForms;
using CaseSystem.Model;
using CaseSystem.Model.PartialClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Attribute = CaseSystem.Model.Attribute;

namespace CaseSystem.MetamodelForms
{
    public partial class AddRequest : Form
    {
        public Model1Container db;
        public Project curProject;
        public Table curTable;
        public Attribute curAtt;
        //private DataTable cond;
        private List<object[]> con;
        private List<Table> tablesList;
        private DataGridView res;

        public AddRequest(ref Model1Container _db, Project curP, ref List<object[]> dt)
        {
            InitializeComponent();

            db = _db;
            curProject = curP;
            con = dt;

            if (con.Count > 0)
            {
                for (int i = 0; i < con.Count; i++)
                {
                    ConditionTable.Rows.Add();
                    ConditionTable.Rows[i].Cells[0].Value = ((Table)con[i][0]).TableName;
                    ConditionTable.Rows[i].Cells[1].Value = ((Attribute)con[i][1]).AttributeName;
                    ConditionTable.Rows[i].Cells[2].Value = (string)con[i][2];
                    ConditionTable.Rows[i].Cells[3].Value = "Удалить";
                }
            }

            tablesList = new List<Table>();
            foreach (Table t in curProject.Table)
            {
                TabBox.Items.Add(t.TableName);
                tablesList.Add(t);
            }
        }

        //public AddRequest(ref Model1Container _db, Project curP, ref DataTable dt)
        //{
        //    InitializeComponent();

        //    db = _db;
        //    curProject = curP;
        //    cond = dt;

        //    if (cond.Rows.Count > 0)
        //    {
        //        for (int i = 0; i < cond.Rows.Count; i++)
        //        {
        //            ConditionTable.Rows.Add();
        //            ConditionTable.Rows[i].Cells[0].Value = ((Table)cond.Rows[i].ItemArray[0]).TableName;
        //            ConditionTable.Rows[i].Cells[1].Value = ((Attribute)cond.Rows[i].ItemArray[1]).AttributeName;
        //            ConditionTable.Rows[i].Cells[2].Value = (string)cond.Rows[i].ItemArray[2];
        //            ConditionTable.Rows[i].Cells[3].Value = "Удалить";
        //        }
        //    }

        //    tablesList = new List<Table>();
        //    foreach (Table t in curProject.Table)
        //    {
        //        TabBox.Items.Add(t.TableName);
        //        tablesList.Add(t);
        //    }
        //}

        private bool IsListTable()
        {
            foreach (Table t in tablesList)
                if (TabBox.Text == t.TableName)
                {
                    curTable = t;
                    return true;
                }
            return false;
        }

        private bool IsListAtt()
        {
            foreach (Attribute at in curTable.Attribute)
                if (AttBox.Text == at.AttributeName)
                {
                    curAtt = at;
                    return true;
                }
            return false;
        }


        private void AddCond_Click(object sender, EventArgs e)
        {
            if (IsListTable() && IsListAtt())
            {
                int row = ConditionTable.Rows.Count;
                string condText = (CondBox.Text == "Условие") ? "" : CondBox.Text;

                if (condText.Length != 0 && condText[0] != '=' && condText[0] != '>' && condText[0] != '<' && condText[0] != '!')
                    MessageBox.Show("Неверное условие. Первым элемент строки должен быть знаком сравнения (>, <, =, !)", "Ошибка добавления условия");
                else
                {
                    ConditionTable.Rows.Add();
                    ConditionTable.Rows[row].Cells[0].Value = curTable.TableName;
                    ConditionTable.Rows[row].Cells[1].Value = curAtt.AttributeName;
                    ConditionTable.Rows[row].Cells[2].Value = (condText.Length != 0 && CondBox.Text[1] == ' ') ?
                                                                    condText[0] + condText.Substring(2) : condText;
                    ConditionTable.Rows[row].Cells[3].Value = "Удалить";

                    // cond.Rows.Add();
                    object[] val = { curTable, curAtt, CondBox.Text };
                    con.Add(val);
                    //cond.Rows[row].ItemArray = val;
                    TabBox.Text = "Таблица";
                    AttBox.Text = "Атрибут";
                    CondBox.Text = "Условие";
                }
            }
            else MessageBox.Show("Неыерный выбор таблицы и/или атрибута", "Ошибка добавления условия");
        }

        private void AttBox_Enter(object sender, EventArgs e)
        {
            AttBox.Items.Clear();

            if (IsListTable())
                foreach (Attribute at in curTable.Attribute)
                    AttBox.Items.Add(at.AttributeName);
        }

        private void TabBox_Leave(object sender, EventArgs e)
        {
            Table prevTab = curTable;
            IsListTable();
            if (prevTab != curTable) AttBox.Text = "Атрибут";
        }

        private void Ok_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ConditionTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (ConditionTable.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
            {
                int col = e.ColumnIndex;
                int row = e.RowIndex;
                con.RemoveAt(row);
                //cond.Rows.RemoveAt(row);
                ConditionTable.Rows.RemoveAt(row);
            }
        }

        private void CondBox_Enter(object sender, EventArgs e)
        {
            if (CondBox.Text == "Условие") CondBox.Text = "";
        }

        private void CondBox_Leave(object sender, EventArgs e)
        {
            if (CondBox.Text == "") CondBox.Text = "Условие";
        }
    }
}
