﻿using CaseSystem.Model;
using CaseSystem.Model.PartialClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CaseSystem.MetamodelForms
{
    public partial class AddProject : Form
    {
        Model1Container db;
        Form1 form;
        public AddProject(ref Model1Container db, Form1 form)
        {           
            InitializeComponent();
            this.form = form;
            this.form.Enabled = false;
            this.db = db;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!PProject.Add(textBox1.Text, ref db))
            {
                MessageBox.Show("Введите имя проекта!");
            }
            else
            {
                form.Enabled = true;
                form.UpdateProject();
                this.Dispose();
                this.Close();
            }
        }
    }
}
