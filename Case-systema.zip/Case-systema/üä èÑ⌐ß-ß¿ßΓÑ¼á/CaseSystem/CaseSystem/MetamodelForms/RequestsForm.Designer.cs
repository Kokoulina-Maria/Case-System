﻿namespace CaseSystem.MetamodelForms
{
    partial class RequestsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.QdChange = new System.Windows.Forms.Button();
            this.RequeResult = new System.Windows.Forms.DataGridView();
            this.ListReq = new System.Windows.Forms.DataGridView();
            this.NameReq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReqID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QdSave = new System.Windows.Forms.Button();
            this.ExportExcel = new System.Windows.Forms.Button();
            this.QdDelete = new System.Windows.Forms.Button();
            this.QdCreateRequest = new System.Windows.Forms.Button();
            this.QdOpen = new System.Windows.Forms.Button();
            this.ReqText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.RequeResult)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ListReq)).BeginInit();
            this.SuspendLayout();
            // 
            // QdChange
            // 
            this.QdChange.Location = new System.Drawing.Point(698, 70);
            this.QdChange.Name = "QdChange";
            this.QdChange.Size = new System.Drawing.Size(156, 23);
            this.QdChange.TabIndex = 5;
            this.QdChange.Text = "Изменить";
            this.QdChange.UseVisualStyleBackColor = true;
            this.QdChange.Click += new System.EventHandler(this.QdChange_Click);
            // 
            // RequeResult
            // 
            this.RequeResult.AllowUserToAddRows = false;
            this.RequeResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.RequeResult.Location = new System.Drawing.Point(197, 41);
            this.RequeResult.Name = "RequeResult";
            this.RequeResult.RowHeadersVisible = false;
            this.RequeResult.Size = new System.Drawing.Size(495, 434);
            this.RequeResult.TabIndex = 6;
            // 
            // ListReq
            // 
            this.ListReq.AllowUserToAddRows = false;
            this.ListReq.AllowUserToDeleteRows = false;
            this.ListReq.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ListReq.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.ListReq.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ListReq.ColumnHeadersVisible = false;
            this.ListReq.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NameReq,
            this.ReqID});
            this.ListReq.GridColor = System.Drawing.Color.White;
            this.ListReq.Location = new System.Drawing.Point(10, 70);
            this.ListReq.MultiSelect = false;
            this.ListReq.Name = "ListReq";
            this.ListReq.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.ListReq.RowHeadersVisible = false;
            this.ListReq.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ListReq.Size = new System.Drawing.Size(181, 405);
            this.ListReq.TabIndex = 7;
            // 
            // NameReq
            // 
            this.NameReq.HeaderText = "Column1";
            this.NameReq.Name = "NameReq";
            // 
            // ReqID
            // 
            this.ReqID.HeaderText = "Column1";
            this.ReqID.Name = "ReqID";
            this.ReqID.Visible = false;
            // 
            // QdSave
            // 
            this.QdSave.Location = new System.Drawing.Point(698, 11);
            this.QdSave.Name = "QdSave";
            this.QdSave.Size = new System.Drawing.Size(156, 24);
            this.QdSave.TabIndex = 8;
            this.QdSave.Text = "Сохранить";
            this.QdSave.UseVisualStyleBackColor = true;
            this.QdSave.Click += new System.EventHandler(this.QdSave_Click);
            // 
            // ExportExcel
            // 
            this.ExportExcel.Location = new System.Drawing.Point(698, 41);
            this.ExportExcel.Name = "ExportExcel";
            this.ExportExcel.Size = new System.Drawing.Size(156, 23);
            this.ExportExcel.TabIndex = 9;
            this.ExportExcel.Text = "Экспорт в Excel";
            this.ExportExcel.UseVisualStyleBackColor = true;
            this.ExportExcel.Click += new System.EventHandler(this.ExportExcel_Click);
            // 
            // QdDelete
            // 
            this.QdDelete.Location = new System.Drawing.Point(698, 99);
            this.QdDelete.Name = "QdDelete";
            this.QdDelete.Size = new System.Drawing.Size(156, 23);
            this.QdDelete.TabIndex = 10;
            this.QdDelete.Text = "Удалить";
            this.QdDelete.UseVisualStyleBackColor = true;
            this.QdDelete.Click += new System.EventHandler(this.QdDelete_Click);
            // 
            // QdCreateRequest
            // 
            this.QdCreateRequest.Location = new System.Drawing.Point(12, 12);
            this.QdCreateRequest.Name = "QdCreateRequest";
            this.QdCreateRequest.Size = new System.Drawing.Size(179, 23);
            this.QdCreateRequest.TabIndex = 11;
            this.QdCreateRequest.Text = "Создать запрос";
            this.QdCreateRequest.UseVisualStyleBackColor = true;
            this.QdCreateRequest.Click += new System.EventHandler(this.QdCreateRequest_Click);
            // 
            // QdOpen
            // 
            this.QdOpen.Location = new System.Drawing.Point(12, 41);
            this.QdOpen.Name = "QdOpen";
            this.QdOpen.Size = new System.Drawing.Size(179, 23);
            this.QdOpen.TabIndex = 12;
            this.QdOpen.Text = "Открыть";
            this.QdOpen.UseVisualStyleBackColor = true;
            this.QdOpen.Click += new System.EventHandler(this.QdOpen_Click);
            // 
            // ReqText
            // 
            this.ReqText.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ReqText.Location = new System.Drawing.Point(270, 12);
            this.ReqText.Name = "ReqText";
            this.ReqText.Size = new System.Drawing.Size(422, 24);
            this.ReqText.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(197, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 18);
            this.label1.TabIndex = 14;
            this.label1.Text = "Запрос: ";
            // 
            // QueryDesign
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(862, 483);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ReqText);
            this.Controls.Add(this.QdOpen);
            this.Controls.Add(this.QdCreateRequest);
            this.Controls.Add(this.QdDelete);
            this.Controls.Add(this.ExportExcel);
            this.Controls.Add(this.QdSave);
            this.Controls.Add(this.ListReq);
            this.Controls.Add(this.RequeResult);
            this.Controls.Add(this.QdChange);
            this.Name = "QueryDesign";
            this.Text = "Запросы";
            ((System.ComponentModel.ISupportInitialize)(this.RequeResult)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ListReq)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button QdChange;
        private System.Windows.Forms.DataGridView RequeResult;
        private System.Windows.Forms.DataGridView ListReq;
        private System.Windows.Forms.Button QdSave;
        private System.Windows.Forms.Button ExportExcel;
        private System.Windows.Forms.Button QdDelete;
        private System.Windows.Forms.Button QdCreateRequest;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameReq;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReqID;
        private System.Windows.Forms.Button QdOpen;
        private System.Windows.Forms.TextBox ReqText;
        private System.Windows.Forms.Label label1;
    }
}