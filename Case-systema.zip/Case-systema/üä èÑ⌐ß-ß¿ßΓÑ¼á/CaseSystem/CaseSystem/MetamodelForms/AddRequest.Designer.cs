﻿namespace CaseSystem.MetamodelForms
{
    partial class AddRequest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.TabBox = new System.Windows.Forms.ComboBox();
            this.AttBox = new System.Windows.Forms.ComboBox();
            this.AddCond = new System.Windows.Forms.Button();
            this.CondBox = new System.Windows.Forms.TextBox();
            this.ConditionTable = new System.Windows.Forms.DataGridView();
            this.NameTab = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NameAtt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Condition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DelEl = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Ok = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ConditionTable)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 290F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.tableLayoutPanel1.Controls.Add(this.TabBox, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.AttBox, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.AddCond, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.CondBox, 2, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(4, 3);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(623, 26);
            this.tableLayoutPanel1.TabIndex = 17;
            // 
            // TabBox
            // 
            this.TabBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TabBox.FormattingEnabled = true;
            this.TabBox.Location = new System.Drawing.Point(3, 3);
            this.TabBox.Name = "TabBox";
            this.TabBox.Size = new System.Drawing.Size(125, 21);
            this.TabBox.TabIndex = 8;
            this.TabBox.Text = "Таблица";
            this.TabBox.Leave += new System.EventHandler(this.TabBox_Leave);
            // 
            // AttBox
            // 
            this.AttBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AttBox.Cursor = System.Windows.Forms.Cursors.Default;
            this.AttBox.FormattingEnabled = true;
            this.AttBox.Location = new System.Drawing.Point(134, 3);
            this.AttBox.Name = "AttBox";
            this.AttBox.Size = new System.Drawing.Size(124, 21);
            this.AttBox.TabIndex = 9;
            this.AttBox.Text = "Атрибут";
            this.AttBox.Enter += new System.EventHandler(this.AttBox_Enter);
            // 
            // AddCond
            // 
            this.AddCond.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AddCond.Location = new System.Drawing.Point(554, 3);
            this.AddCond.Name = "AddCond";
            this.AddCond.Size = new System.Drawing.Size(66, 20);
            this.AddCond.TabIndex = 6;
            this.AddCond.Text = "Добавить";
            this.AddCond.UseVisualStyleBackColor = true;
            this.AddCond.Click += new System.EventHandler(this.AddCond_Click);
            // 
            // CondBox
            // 
            this.CondBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CondBox.Location = new System.Drawing.Point(264, 3);
            this.CondBox.Name = "CondBox";
            this.CondBox.Size = new System.Drawing.Size(284, 20);
            this.CondBox.TabIndex = 10;
            this.CondBox.Text = "Условие";
            this.CondBox.Enter += new System.EventHandler(this.CondBox_Enter);
            this.CondBox.Leave += new System.EventHandler(this.CondBox_Leave);
            // 
            // ConditionTable
            // 
            this.ConditionTable.AllowUserToAddRows = false;
            this.ConditionTable.AllowUserToDeleteRows = false;
            this.ConditionTable.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ConditionTable.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.ConditionTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ConditionTable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NameTab,
            this.NameAtt,
            this.Condition,
            this.DelEl});
            this.ConditionTable.Location = new System.Drawing.Point(4, 32);
            this.ConditionTable.Name = "ConditionTable";
            this.ConditionTable.RowHeadersVisible = false;
            this.ConditionTable.ShowEditingIcon = false;
            this.ConditionTable.Size = new System.Drawing.Size(624, 241);
            this.ConditionTable.TabIndex = 15;
            this.ConditionTable.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ConditionTable_CellContentClick);
            // 
            // NameTab
            // 
            this.NameTab.HeaderText = "Таблица";
            this.NameTab.Name = "NameTab";
            this.NameTab.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.NameTab.Width = 130;
            // 
            // NameAtt
            // 
            this.NameAtt.HeaderText = "Атрибут";
            this.NameAtt.Name = "NameAtt";
            this.NameAtt.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.NameAtt.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NameAtt.Width = 130;
            // 
            // Condition
            // 
            this.Condition.HeaderText = "Условие";
            this.Condition.Name = "Condition";
            this.Condition.Width = 290;
            // 
            // DelEl
            // 
            this.DelEl.HeaderText = "Удалить";
            this.DelEl.Name = "DelEl";
            this.DelEl.Text = "Удалить";
            this.DelEl.ToolTipText = "Удалить";
            this.DelEl.Width = 70;
            // 
            // Ok
            // 
            this.Ok.Location = new System.Drawing.Point(430, 279);
            this.Ok.Name = "Ok";
            this.Ok.Size = new System.Drawing.Size(198, 23);
            this.Ok.TabIndex = 16;
            this.Ok.Text = "Создать";
            this.Ok.UseVisualStyleBackColor = true;
            this.Ok.Click += new System.EventHandler(this.Ok_Click);
            // 
            // AddRequest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(635, 307);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.ConditionTable);
            this.Controls.Add(this.Ok);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddRequest";
            this.Text = "Создание запроса";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ConditionTable)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ComboBox TabBox;
        private System.Windows.Forms.ComboBox AttBox;
        private System.Windows.Forms.Button AddCond;
        private System.Windows.Forms.TextBox CondBox;
        private System.Windows.Forms.DataGridView ConditionTable;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameTab;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameAtt;
        private System.Windows.Forms.DataGridViewTextBoxColumn Condition;
        private System.Windows.Forms.DataGridViewButtonColumn DelEl;
        private System.Windows.Forms.Button Ok;
    }
}