﻿using CaseSystem.MetamodelForms;
using CaseSystem.Model;
using CaseSystem.Model.PartialClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Attribute = CaseSystem.Model.Attribute;
using ExcelObj = Microsoft.Office.Interop.Excel;

namespace CaseSystem.MetamodelForms
{
    public partial class QueryDesign : Form
    {
        public Model1Container db;
        public Project curProject;
        public Table curTable;
        private Requests curReq;
        //private DataTable cond;
        private List<object[]> con;

        public QueryDesign(ref Model1Container _db, Project curP)
        {
            InitializeComponent();
            db = _db;
            curProject = curP;
            con = new List<object[]>();

            ClearTable(ListReq);
            // Вывод списка существующих запросов
            foreach (Requests rq in db.RequestsSet)
            {
                try
                {
                    if (rq.ReqElem.First().Attribute.Table.Project.IDProject == curProject.IDProject)
                    {
                        ListReq.Rows.Add();
                        ListReq.Rows[0].Cells[0].Value = rq.ReqName;
                        ListReq.Rows[0].Cells[1].Value = rq;
                    }
                }
                catch (Exception)
                {

                }
            }
        }

        private void QdCreateRequest_Click(object sender, EventArgs e)
        {
            con = new List<object[]>();


            //cond = new DataTable();
            //cond.Columns.Add("TTab", typeof(Table));
            //cond.Columns.Add("TAtt", typeof(Attribute));
            //cond.Columns.Add("TCom", typeof(string));

            //AddRequest add = new AddRequest(ref db, curProject, ref cond);
            AddRequest add = new AddRequest(ref db, curProject, ref con);
            add.ShowDialog();

            //RequeResult.DataSource = FuncRequery.Func(db, cond);
            RequeResult.DataSource = FuncRequery.Func(db, con);

        }

        private void QdOpen_Click(object sender, EventArgs e)
        {
            curReq = (Requests)ListReq.SelectedRows[0].Cells[1].Value;
            ReqText.Text = curReq.ReqName;

            con = new List<object[]>();

            //cond = new DataTable();
            //cond.Columns.Add("TTab", typeof(Table));
            //cond.Columns.Add("TAtt", typeof(Attribute));
            //cond.Columns.Add("TCom", typeof(string));

            foreach (ReqElem re in curReq.ReqElem)
            {
                int row = con.Count;
                object[] val = { re.Attribute.Table, re.Attribute, re.Condition };
                con.Add(val);

                //int row = cond.Rows.Count;
                //cond.Rows.Add();
                //object[] val = { re.Attribute.Table, re.Attribute, re.Condition };
                //cond.Rows[row].ItemArray = val;
            }
            //RequeResult.DataSource = FuncRequery.Func(db, cond);
            RequeResult.DataSource = FuncRequery.Func(db, con);
        }

        private void QdSave_Click(object sender, EventArgs e)
        {
            if (ReqText.Text == "")
                MessageBox.Show("Введите название запроса", "Ошибка сохранения");
            else
            {
                Requests rq = PRequests.Create(ref db, curProject, ReqText.Text, (Attribute)con[0][1], (string)con[0][2]);
                for (int i = 1; i < con.Count; i++)
                {
                    PRequests.Add(ref db, rq, (Attribute)con[i][1], (string)con[i][2]);
                }
                ListReq.Rows.Add();
                int row = ListReq.Rows.Count - 1;
                ListReq.Rows[row].Cells[0].Value = rq.ReqName;
                ListReq.Rows[row].Cells[1].Value = rq;



                //Requests rq = PRequests.Create(ref db, curProject, ReqText.Text, (Attribute)cond.Rows[0].ItemArray[1], (string)cond.Rows[0].ItemArray[2]);
                //for (int i = 1; i < cond.Rows.Count; i++)
                //{
                //    PRequests.Add(ref db, rq, (Attribute)cond.Rows[i].ItemArray[1], (string)cond.Rows[i].ItemArray[2]);
                //}
                //ListReq.Rows.Add();
                //int row = ListReq.Rows.Count - 1;
                //ListReq.Rows[row].Cells[0].Value = rq.ReqName;
                //ListReq.Rows[row].Cells[1].Value = rq;
            }
        }

        private void QdChange_Click(object sender, EventArgs e)
        {
            //AddRequest add = new AddRequest(ref db, curProject, ref cond);
            AddRequest add = new AddRequest(ref db, curProject, ref con);
            add.ShowDialog();
            //RequeResult.DataSource = FuncRequery.Func(db, cond);
            RequeResult.DataSource = FuncRequery.Func(db, con);
        }

        private void QdDelete_Click(object sender, EventArgs e)
        {
            string mes = "Вы действительно хотите удалить запрос " + curReq.ReqName + "?";
            DialogResult dRes = MessageBox.Show(mes, "Удаление запроса", MessageBoxButtons.YesNo);
            if (dRes == DialogResult.Yes)
            {
                PRequests.Delete(ref db, curReq);
                // Вывод списка существующих запросов
                ClearTable(ListReq);
                ClearTable(RequeResult);

                foreach (Requests rq in db.RequestsSet)
                {
                    if (rq.ReqElem.First().Attribute.Table.Project.IDProject == curProject.IDProject)
                    {
                        ListReq.Rows.Add();
                        ListReq.Rows[0].Cells[0].Value = rq.ReqName;
                        ListReq.Rows[0].Cells[1].Value = rq;
                    }
                }
            }
        }

        private void ClearTable(DataGridView dgv)
        {
            while (dgv.Rows.Count > 0)
                dgv.Rows.Remove(dgv.Rows[0]);
        }

        private void ExportExcel_Click(object sender, EventArgs e)
        {
            ExcelObj.Application app = new ExcelObj.Application();
            SaveFileDialog save = new SaveFileDialog();
            save.DefaultExt = "*.xls;*.xlsx";
            save.CheckFileExists = true;
            save.ShowDialog();
            if (save.ShowDialog() == DialogResult.OK && save.FileName == "")
            {
                string NameFile = save.FileName;
                ExcelObj.Worksheet Sheet;         
                app.SheetsInNewWorkbook = 1;
                app.Workbooks.Add(Type.Missing);
                Sheet = (ExcelObj.Worksheet)app.Sheets.get_Item(1);
                app.DisplayAlerts = false;
                // Переносим данные в документ 
                for (int i = 0; i < RequeResult.ColumnCount; i++)
                    Sheet.Cells[1, i + 1] = RequeResult.Columns[i].HeaderText;
                for (int i = 0; i< RequeResult.Rows.Count; i++)
                {
                    for (int j = 0; j < RequeResult.ColumnCount; j++)
                        Sheet.Cells[i + 1, j + 1] = RequeResult[i, j];
                }
                // Закрываем файл
                app.DisplayAlerts = true;
                app.ActiveWorkbook.Close();
                app.Quit();
            }


        }


    }
}
