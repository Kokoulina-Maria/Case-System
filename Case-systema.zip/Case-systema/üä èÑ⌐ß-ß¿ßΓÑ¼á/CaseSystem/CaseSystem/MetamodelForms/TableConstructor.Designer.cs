﻿namespace CaseSystem.MetamodelForms
{
    partial class TableConstructor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dgvAttributes = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.tbName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbType = new System.Windows.Forms.ComboBox();
            this.chbIskey = new System.Windows.Forms.CheckBox();
            this.chbIsrequired = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbInitialValue = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.nudLength = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.tbMax = new System.Windows.Forms.TextBox();
            this.tbMin = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cbConnectionType = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAttributes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLength)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Атрибуты:";
            // 
            // dgvAttributes
            // 
            this.dgvAttributes.AllowUserToAddRows = false;
            this.dgvAttributes.AllowUserToDeleteRows = false;
            this.dgvAttributes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAttributes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAttributes.Location = new System.Drawing.Point(43, 60);
            this.dgvAttributes.MultiSelect = false;
            this.dgvAttributes.Name = "dgvAttributes";
            this.dgvAttributes.ReadOnly = true;
            this.dgvAttributes.RowTemplate.Height = 24;
            this.dgvAttributes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAttributes.Size = new System.Drawing.Size(440, 379);
            this.dgvAttributes.TabIndex = 1;
            this.dgvAttributes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAttributes_CellContentClick);
            this.dgvAttributes.Click += new System.EventHandler(this.dgvAttributes_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(503, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Название:";
            // 
            // tbName
            // 
            this.tbName.Location = new System.Drawing.Point(693, 60);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(287, 22);
            this.tbName.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(503, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Тип:";
            // 
            // cbType
            // 
            this.cbType.FormattingEnabled = true;
            this.cbType.Items.AddRange(new object[] {
            "int",
            "double",
            "boolean",
            "DateTime",
            "string",
            "Подстановка",
            "Счетчик"});
            this.cbType.Location = new System.Drawing.Point(693, 105);
            this.cbType.Name = "cbType";
            this.cbType.Size = new System.Drawing.Size(287, 24);
            this.cbType.TabIndex = 5;
            this.cbType.SelectedIndexChanged += new System.EventHandler(this.cbType_SelectedIndexChanged);
            this.cbType.TextUpdate += new System.EventHandler(this.cbType_TextUpdate);
            this.cbType.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbType_KeyPress);
            // 
            // chbIskey
            // 
            this.chbIskey.AutoSize = true;
            this.chbIskey.Location = new System.Drawing.Point(693, 148);
            this.chbIskey.Name = "chbIskey";
            this.chbIskey.Size = new System.Drawing.Size(96, 21);
            this.chbIskey.TabIndex = 7;
            this.chbIskey.Text = "Ключевое";
            this.chbIskey.UseVisualStyleBackColor = true;
            // 
            // chbIsrequired
            // 
            this.chbIsrequired.AutoSize = true;
            this.chbIsrequired.Location = new System.Drawing.Point(693, 184);
            this.chbIsrequired.Name = "chbIsrequired";
            this.chbIsrequired.Size = new System.Drawing.Size(126, 21);
            this.chbIsrequired.TabIndex = 8;
            this.chbIsrequired.Text = "Обязательное";
            this.chbIsrequired.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(503, 224);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(152, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "Начальное значение:";
            // 
            // tbInitialValue
            // 
            this.tbInitialValue.Location = new System.Drawing.Point(693, 221);
            this.tbInitialValue.Name = "tbInitialValue";
            this.tbInitialValue.Size = new System.Drawing.Size(287, 22);
            this.tbInitialValue.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(503, 269);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(153, 17);
            this.label5.TabIndex = 11;
            this.label5.Text = "Максимальная длина:";
            // 
            // nudLength
            // 
            this.nudLength.Increment = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nudLength.Location = new System.Drawing.Point(693, 267);
            this.nudLength.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudLength.Name = "nudLength";
            this.nudLength.Size = new System.Drawing.Size(120, 22);
            this.nudLength.TabIndex = 12;
            this.nudLength.Value = new decimal(new int[] {
            255,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(503, 309);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(176, 17);
            this.label6.TabIndex = 13;
            this.label6.Text = "Максимальное значение:";
            // 
            // tbMax
            // 
            this.tbMax.Location = new System.Drawing.Point(693, 306);
            this.tbMax.Name = "tbMax";
            this.tbMax.Size = new System.Drawing.Size(287, 22);
            this.tbMax.TabIndex = 14;
            // 
            // tbMin
            // 
            this.tbMin.Location = new System.Drawing.Point(693, 349);
            this.tbMin.Name = "tbMin";
            this.tbMin.Size = new System.Drawing.Size(287, 22);
            this.tbMin.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(503, 352);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(170, 17);
            this.label7.TabIndex = 15;
            this.label7.Text = "Минимальное значение:";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(355, 8);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(128, 36);
            this.btnAdd.TabIndex = 17;
            this.btnAdd.Text = "Новый атрибут";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(873, 390);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(107, 42);
            this.btnSave.TabIndex = 18;
            this.btnSave.Text = "Сохранить изменения";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(228, 8);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(83, 36);
            this.btnDelete.TabIndex = 19;
            this.btnDelete.Text = "Удалить";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(503, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 17);
            this.label8.TabIndex = 20;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(986, 108);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 17);
            this.label9.TabIndex = 21;
            this.label9.Text = "Связь:";
            // 
            // cbConnectionType
            // 
            this.cbConnectionType.AutoSize = true;
            this.cbConnectionType.Location = new System.Drawing.Point(1042, 107);
            this.cbConnectionType.Name = "cbConnectionType";
            this.cbConnectionType.Size = new System.Drawing.Size(88, 21);
            this.cbConnectionType.TabIndex = 22;
            this.cbConnectionType.Text = "Жесткая";
            this.cbConnectionType.UseVisualStyleBackColor = true;
            this.cbConnectionType.CheckedChanged += new System.EventHandler(this.cbConnectionType_CheckedChanged);
            // 
            // TableConstructor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1145, 472);
            this.Controls.Add(this.cbConnectionType);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.tbMin);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tbMax);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.nudLength);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tbInitialValue);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.chbIsrequired);
            this.Controls.Add(this.chbIskey);
            this.Controls.Add(this.cbType);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvAttributes);
            this.Controls.Add(this.label1);
            this.MaximumSize = new System.Drawing.Size(1163, 519);
            this.MinimumSize = new System.Drawing.Size(1027, 519);
            this.Name = "TableConstructor";
            this.Text = "Конструктор таблицы";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TableConstructor_FormClosing);
            this.Load += new System.EventHandler(this.TableConstructor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAttributes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLength)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvAttributes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbType;
        private System.Windows.Forms.CheckBox chbIskey;
        private System.Windows.Forms.CheckBox chbIsrequired;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbInitialValue;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nudLength;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbMax;
        private System.Windows.Forms.TextBox tbMin;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox cbConnectionType;
    }
}