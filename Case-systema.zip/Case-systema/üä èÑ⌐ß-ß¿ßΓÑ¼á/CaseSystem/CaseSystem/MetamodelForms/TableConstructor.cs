﻿using CaseSystem.Model;
using CaseSystem.Model.PartialClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CaseSystem.MetamodelForms
{
    public partial class TableConstructor : Form
    {
        Model1Container db;
        Form1 form;
        Table table=null;
        bool nowNew;
        public Table RefTable;
        public bool IsHurd;
        public bool addConnection=false;
        public bool wasConnection;
        public bool changeConnection;
        public TableConstructor(Form1 form, Table t, ref Model1Container db)
        {           
            InitializeComponent();
            this.form = form;
            this.form.Enabled = false;
            table = t;
            this.db = db;
            UpdateAttribute();
            label8.Text = "";
            label9.Visible = false;
            cbConnectionType.Visible = false;
            this.Text = "Конструктор таблицы " + table.TableName;
        }

        public void UpdateAttribute()
        {
            if (db.TableSet.Find(table.IDTable).Attribute.Count() > 0)
            {
                dgvAttributes.DataSource = (from a in db.TableSet.Find(table.IDTable).Attribute select new {a.IDAttribute, a.IsKey, a.AttributeName, a.AttributeType}).ToList();
                dgvAttributes.Columns[0].Visible = false;
                dgvAttributes.Columns[1].HeaderText = "Ключ";
                dgvAttributes.Columns[2].HeaderText = "Название";
                dgvAttributes.Columns[3].HeaderText = "Тип";
                dgvAttributes.Update();
            }
            else dgvAttributes.DataSource = null;
            dgvAttributes.Update();
        }

        public void Information()
        {
            if (dgvAttributes.SelectedRows.Count == 1)
            {
                tbName.Text = db.AttributeSet.Find(dgvAttributes.SelectedRows[0].Cells[0].Value).AttributeName;
                cbType.Text = db.AttributeSet.Find(dgvAttributes.SelectedRows[0].Cells[0].Value).AttributeType;
                chbIskey.Checked = db.AttributeSet.Find(dgvAttributes.SelectedRows[0].Cells[0].Value).IsKey;
                chbIsrequired.Checked = db.AttributeSet.Find(dgvAttributes.SelectedRows[0].Cells[0].Value).IsRecuired;
                cbType.Text = db.AttributeSet.Find(dgvAttributes.SelectedRows[0].Cells[0].Value).AttributeType;
                if (cbType.Text == "Подстановка")
                {
                    wasConnection = true;
                    cbType.Text = cbType.Text + ": " + db.AttributeSet.Find(dgvAttributes.SelectedRows[0].Cells[0].Value).Connection.Table.TableName;
                    cbType.Enabled = false;
                    label8.Text = "Если Вы хотите удалить или изменить связь, удалите данный атрибут и создайте новый";
                    label9.Visible = true;
                    cbConnectionType.Visible = true;
                    cbConnectionType.Checked = db.AttributeSet.Find(dgvAttributes.SelectedRows[0].Cells[0].Value).Connection.IsHard;
                }
                else
                {
                    wasConnection = false;
                    cbType.Enabled = true;
                    label8.Text = "";
                    label9.Visible = false;
                    cbConnectionType.Visible = false;
                }
                tbInitialValue.Text = db.AttributeSet.Find(dgvAttributes.SelectedRows[0].Cells[0].Value).InitialValue;
                nudLength.Value = (decimal)db.AttributeSet.Find(dgvAttributes.SelectedRows[0].Cells[0].Value).MaximumLength;
                tbMax.Text= db.AttributeSet.Find(dgvAttributes.SelectedRows[0].Cells[0].Value).MaximumValue;
                tbMin.Text= db.AttributeSet.Find(dgvAttributes.SelectedRows[0].Cells[0].Value).MinimumValue;
                nowNew = false;
                btnSave.Enabled = true;
            }
            else
            {
                btnSave.Enabled = false;
            }
        }

        private void TableConstructor_Load(object sender, EventArgs e)
        {
            Information();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult d = MessageBox.Show("При удалении данного атрибута скорее всего произойдет потеря данных. Вы уверены, что хотите удалить данный атрибут?", "Удаление атрибута", MessageBoxButtons.YesNo);
            if (d == DialogResult.Yes)
            {
                PAttribute.Delete((int)dgvAttributes.SelectedRows[0].Cells[0].Value, ref db);
                UpdateAttribute();
            }
        }

        private void dgvAttributes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
                  
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cbType.Text.Contains("Подстановка")) cbType.Text = "Подстановка";
            string m;
            if (!nowNew)
            {
                if (!PAttribute.Check(tbName.Text, cbType.Text, chbIsrequired.Checked, tbInitialValue.Text, (byte?)nudLength.Value, chbIskey.Checked, tbMax.Text, tbMin.Text, out m, table, (int)dgvAttributes.SelectedRows[0].Cells[0].Value, ref db))
                {
                    MessageBox.Show(m);
                }
                else
                {
                    DialogResult d = MessageBox.Show("При редактировании данного атрибута скорее всего произойдет потеря данных. Вы уверены, что хотите сохранить изменения?", "Редактирование атрибута", MessageBoxButtons.YesNo);
                    if (d == DialogResult.Yes)
                    {
                        if (wasConnection) PConnection.Change(db.AttributeSet.Find(dgvAttributes.SelectedRows[0].Cells[0].Value).Connection.IDConnection, cbConnectionType.Checked, ref db);
                        PAttribute.Edit(tbName.Text, cbType.Text, chbIsrequired.Checked, tbInitialValue.Text, (byte?)nudLength.Value, chbIskey.Checked, tbMax.Text, tbMin.Text, (int)dgvAttributes.SelectedRows[0].Cells[0].Value, ref db);
                        UpdateAttribute();
                    }
                }
            }
            else
            {

                {
                    if (!PAttribute.Check(tbName.Text, cbType.Text, chbIskey.Checked, tbInitialValue.Text, (byte?)nudLength.Value, chbIskey.Checked, tbMax.Text, tbMin.Text, out m, table, default(int), ref db))
                    {
                        MessageBox.Show(m);
                    }
                    else
                    {
                        if (addConnection && IsHurd && table.Example.Count>0) MessageBox.Show("В данной таблице уже есть элементы, которые не имеют жесткой связи. Сначала очистите таблицу, а потом добавьте атрибут");
                        else
                        {
                            PAttribute.Add(tbName.Text, cbType.Text, chbIsrequired.Checked, tbInitialValue.Text, (byte?)nudLength.Value, chbIskey.Checked, tbMax.Text, tbMin.Text, table, ref db);
                            Model.Attribute a = (from atr in db.AttributeSet where atr.Table.IDTable == table.IDTable && atr.AttributeName == tbName.Text select atr).First();
                            if (addConnection) PConnection.Add(a, RefTable, IsHurd, ref db);
                            UpdateAttribute();
                        }
                    }
                }
            }
        }

        private void cbType_TextUpdate(object sender, EventArgs e)
        {

        }
        public void AfterAddConnection(bool ok, Table refT, bool ishurd)
        {
            if (ok)
            {
                RefTable = refT;
                IsHurd = ishurd;
                addConnection = true;
                cbType.Text = cbType.Text + ": " + refT.TableName;
                label9.Visible = true;
                cbConnectionType.Visible = true;
                cbConnectionType.Checked = ishurd;
            }
            else cbType.Text = "string";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            UserAddAttribute();
        }

        public void UserAddAttribute()
        {
            nowNew = true;
            btnSave.Enabled = true;
            tbName.Text = null;
            cbType.Enabled = true;
            cbType.Text = null;
            chbIskey.Checked = false;
            chbIsrequired.Checked = false;
            cbType.Text = null;
            tbInitialValue.Text = null;
            nudLength.Value = 255;
            tbMax.Text = null;
            tbMin.Text = null;
            wasConnection = false;
            label8.Text = "";
            label9.Visible = false;
            cbConnectionType.Visible = false;
        }

        private void cbType_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbType.Text != "string")
            {
                nudLength.Value = default(decimal);
                nudLength.Enabled = false;
            }
            else
            {
                nudLength.Value = 255;
                nudLength.Enabled = true;
            }

            if (cbType.Text != "double" && cbType.Text != "int" && cbType.Text != "DateTime") { tbMax.Enabled = false; tbMin.Enabled = false; }
            else { tbMax.Enabled = true; tbMin.Enabled = true; }

            if (cbType.Text == "Подстановка")
            {
                if (nowNew)
                {
                    AddConnection form = new AddConnection(this, ref db, table.Project);
                    form.Show();
                }
            }
            else
            {
                addConnection = false;
            }
        }

        private void dgvAttributes_Click(object sender, EventArgs e)
        {
            Information();
        }

        private void TableConstructor_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!PTable.Check(table.IDTable, ref db))
            {
                MessageBox.Show("В таблице толжно быть хотя бы одно ключевое поле!");
                e.Cancel = true;
            }
            else
            {
                form.Enabled = true;
            }
        }

        private void cbConnectionType_CheckedChanged(object sender, EventArgs e)
        {
            IsHurd = cbConnectionType.Checked;
        }
    }
}
