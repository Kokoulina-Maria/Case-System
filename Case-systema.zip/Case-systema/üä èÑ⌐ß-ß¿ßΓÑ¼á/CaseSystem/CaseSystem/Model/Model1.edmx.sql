
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 12/19/2018 12:18:51
-- Generated from EDMX file: C:\Users\Mariia\Desktop\Homeworks_3_cource\БД\Case-systema\БД Кейс-система\CaseSystem\CaseSystem\Model\Model1.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Case];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_AttributeValues]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ValuesSet] DROP CONSTRAINT [FK_AttributeValues];
GO
IF OBJECT_ID(N'[dbo].[FK_ExampleValues]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ValuesSet] DROP CONSTRAINT [FK_ExampleValues];
GO
IF OBJECT_ID(N'[dbo].[FK_TableAttribute]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[AttributeSet] DROP CONSTRAINT [FK_TableAttribute];
GO
IF OBJECT_ID(N'[dbo].[FK_TableExample]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ExampleSet] DROP CONSTRAINT [FK_TableExample];
GO
IF OBJECT_ID(N'[dbo].[FK_TableConnection]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ConnectionSet] DROP CONSTRAINT [FK_TableConnection];
GO
IF OBJECT_ID(N'[dbo].[FK_AttributeConnection]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ConnectionSet] DROP CONSTRAINT [FK_AttributeConnection];
GO
IF OBJECT_ID(N'[dbo].[FK_ProjectTable]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[TableSet] DROP CONSTRAINT [FK_ProjectTable];
GO
IF OBJECT_ID(N'[dbo].[FK_RequestReqElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ReqElementSet] DROP CONSTRAINT [FK_RequestReqElement];
GO
IF OBJECT_ID(N'[dbo].[FK_AttributeReqElement]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[ReqElementSet] DROP CONSTRAINT [FK_AttributeReqElement];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[ProjectSet]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ProjectSet];
GO
IF OBJECT_ID(N'[dbo].[TableSet]', 'U') IS NOT NULL
    DROP TABLE [dbo].[TableSet];
GO
IF OBJECT_ID(N'[dbo].[AttributeSet]', 'U') IS NOT NULL
    DROP TABLE [dbo].[AttributeSet];
GO
IF OBJECT_ID(N'[dbo].[ValuesSet]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ValuesSet];
GO
IF OBJECT_ID(N'[dbo].[ConnectionSet]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ConnectionSet];
GO
IF OBJECT_ID(N'[dbo].[ExampleSet]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ExampleSet];
GO
IF OBJECT_ID(N'[dbo].[RequestSet]', 'U') IS NOT NULL
    DROP TABLE [dbo].[RequestSet];
GO
IF OBJECT_ID(N'[dbo].[ReqElementSet]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ReqElementSet];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'ProjectSet'
CREATE TABLE [dbo].[ProjectSet] (
    [IDProject] int IDENTITY(1,1) NOT NULL,
    [ProjectName] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'TableSet'
CREATE TABLE [dbo].[TableSet] (
    [IDTable] int IDENTITY(1,1) NOT NULL,
    [TableName] nvarchar(max)  NOT NULL,
    [CurrentID] int  NULL,
    [Project_IDProject] int  NOT NULL
);
GO

-- Creating table 'AttributeSet'
CREATE TABLE [dbo].[AttributeSet] (
    [IDAttribute] int IDENTITY(1,1) NOT NULL,
    [AttributeName] nvarchar(max)  NOT NULL,
    [AttributeType] nvarchar(max)  NOT NULL,
    [IsRecuired] bit  NOT NULL,
    [InitialValue] nvarchar(max)  NULL,
    [MaximumLength] tinyint  NULL,
    [IsKey] bit  NOT NULL,
    [MaximumValue] nvarchar(max)  NULL,
    [MinimumValue] nvarchar(max)  NULL,
    [Table_IDTable] int  NOT NULL
);
GO

-- Creating table 'ValuesSet'
CREATE TABLE [dbo].[ValuesSet] (
    [IDValue] bigint IDENTITY(1,1) NOT NULL,
    [Content] nvarchar(max)  NOT NULL,
    [Attribute_IDAttribute] int  NOT NULL,
    [Example_IDExample] bigint  NOT NULL
);
GO

-- Creating table 'ConnectionSet'
CREATE TABLE [dbo].[ConnectionSet] (
    [IDConnection] int IDENTITY(1,1) NOT NULL,
    [IsHard] bit  NOT NULL,
    [Table_IDTable] int  NOT NULL,
    [Attribute_IDAttribute] int  NOT NULL
);
GO

-- Creating table 'ExampleSet'
CREATE TABLE [dbo].[ExampleSet] (
    [IDExample] bigint IDENTITY(1,1) NOT NULL,
    [VisibleID] int  NOT NULL,
    [Table_IDTable] int  NOT NULL
);
GO

-- Creating table 'RequestSet'
CREATE TABLE [dbo].[RequestSet] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [RequestName] nvarchar(max)  NOT NULL
);
GO

-- Creating table 'ReqElementSet'
CREATE TABLE [dbo].[ReqElementSet] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Condition] nvarchar(max)  NOT NULL,
    [Sign] nvarchar(max)  NOT NULL,
    [Request_Id] int  NOT NULL,
    [Attribute_IDAttribute] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [IDProject] in table 'ProjectSet'
ALTER TABLE [dbo].[ProjectSet]
ADD CONSTRAINT [PK_ProjectSet]
    PRIMARY KEY CLUSTERED ([IDProject] ASC);
GO

-- Creating primary key on [IDTable] in table 'TableSet'
ALTER TABLE [dbo].[TableSet]
ADD CONSTRAINT [PK_TableSet]
    PRIMARY KEY CLUSTERED ([IDTable] ASC);
GO

-- Creating primary key on [IDAttribute] in table 'AttributeSet'
ALTER TABLE [dbo].[AttributeSet]
ADD CONSTRAINT [PK_AttributeSet]
    PRIMARY KEY CLUSTERED ([IDAttribute] ASC);
GO

-- Creating primary key on [IDValue] in table 'ValuesSet'
ALTER TABLE [dbo].[ValuesSet]
ADD CONSTRAINT [PK_ValuesSet]
    PRIMARY KEY CLUSTERED ([IDValue] ASC);
GO

-- Creating primary key on [IDConnection] in table 'ConnectionSet'
ALTER TABLE [dbo].[ConnectionSet]
ADD CONSTRAINT [PK_ConnectionSet]
    PRIMARY KEY CLUSTERED ([IDConnection] ASC);
GO

-- Creating primary key on [IDExample] in table 'ExampleSet'
ALTER TABLE [dbo].[ExampleSet]
ADD CONSTRAINT [PK_ExampleSet]
    PRIMARY KEY CLUSTERED ([IDExample] ASC);
GO

-- Creating primary key on [Id] in table 'RequestSet'
ALTER TABLE [dbo].[RequestSet]
ADD CONSTRAINT [PK_RequestSet]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'ReqElementSet'
ALTER TABLE [dbo].[ReqElementSet]
ADD CONSTRAINT [PK_ReqElementSet]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [Attribute_IDAttribute] in table 'ValuesSet'
ALTER TABLE [dbo].[ValuesSet]
ADD CONSTRAINT [FK_AttributeValues]
    FOREIGN KEY ([Attribute_IDAttribute])
    REFERENCES [dbo].[AttributeSet]
        ([IDAttribute])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AttributeValues'
CREATE INDEX [IX_FK_AttributeValues]
ON [dbo].[ValuesSet]
    ([Attribute_IDAttribute]);
GO

-- Creating foreign key on [Example_IDExample] in table 'ValuesSet'
ALTER TABLE [dbo].[ValuesSet]
ADD CONSTRAINT [FK_ExampleValues]
    FOREIGN KEY ([Example_IDExample])
    REFERENCES [dbo].[ExampleSet]
        ([IDExample])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ExampleValues'
CREATE INDEX [IX_FK_ExampleValues]
ON [dbo].[ValuesSet]
    ([Example_IDExample]);
GO

-- Creating foreign key on [Table_IDTable] in table 'AttributeSet'
ALTER TABLE [dbo].[AttributeSet]
ADD CONSTRAINT [FK_TableAttribute]
    FOREIGN KEY ([Table_IDTable])
    REFERENCES [dbo].[TableSet]
        ([IDTable])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_TableAttribute'
CREATE INDEX [IX_FK_TableAttribute]
ON [dbo].[AttributeSet]
    ([Table_IDTable]);
GO

-- Creating foreign key on [Table_IDTable] in table 'ExampleSet'
ALTER TABLE [dbo].[ExampleSet]
ADD CONSTRAINT [FK_TableExample]
    FOREIGN KEY ([Table_IDTable])
    REFERENCES [dbo].[TableSet]
        ([IDTable])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_TableExample'
CREATE INDEX [IX_FK_TableExample]
ON [dbo].[ExampleSet]
    ([Table_IDTable]);
GO

-- Creating foreign key on [Table_IDTable] in table 'ConnectionSet'
ALTER TABLE [dbo].[ConnectionSet]
ADD CONSTRAINT [FK_TableConnection]
    FOREIGN KEY ([Table_IDTable])
    REFERENCES [dbo].[TableSet]
        ([IDTable])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_TableConnection'
CREATE INDEX [IX_FK_TableConnection]
ON [dbo].[ConnectionSet]
    ([Table_IDTable]);
GO

-- Creating foreign key on [Attribute_IDAttribute] in table 'ConnectionSet'
ALTER TABLE [dbo].[ConnectionSet]
ADD CONSTRAINT [FK_AttributeConnection]
    FOREIGN KEY ([Attribute_IDAttribute])
    REFERENCES [dbo].[AttributeSet]
        ([IDAttribute])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AttributeConnection'
CREATE INDEX [IX_FK_AttributeConnection]
ON [dbo].[ConnectionSet]
    ([Attribute_IDAttribute]);
GO

-- Creating foreign key on [Project_IDProject] in table 'TableSet'
ALTER TABLE [dbo].[TableSet]
ADD CONSTRAINT [FK_ProjectTable]
    FOREIGN KEY ([Project_IDProject])
    REFERENCES [dbo].[ProjectSet]
        ([IDProject])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_ProjectTable'
CREATE INDEX [IX_FK_ProjectTable]
ON [dbo].[TableSet]
    ([Project_IDProject]);
GO

-- Creating foreign key on [Request_Id] in table 'ReqElementSet'
ALTER TABLE [dbo].[ReqElementSet]
ADD CONSTRAINT [FK_RequestReqElement]
    FOREIGN KEY ([Request_Id])
    REFERENCES [dbo].[RequestSet]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_RequestReqElement'
CREATE INDEX [IX_FK_RequestReqElement]
ON [dbo].[ReqElementSet]
    ([Request_Id]);
GO

-- Creating foreign key on [Attribute_IDAttribute] in table 'ReqElementSet'
ALTER TABLE [dbo].[ReqElementSet]
ADD CONSTRAINT [FK_AttributeReqElement]
    FOREIGN KEY ([Attribute_IDAttribute])
    REFERENCES [dbo].[AttributeSet]
        ([IDAttribute])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AttributeReqElement'
CREATE INDEX [IX_FK_AttributeReqElement]
ON [dbo].[ReqElementSet]
    ([Attribute_IDAttribute]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------