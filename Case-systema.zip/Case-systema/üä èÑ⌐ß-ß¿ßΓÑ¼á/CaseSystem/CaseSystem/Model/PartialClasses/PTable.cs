﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseSystem.Model.PartialClasses
{
    /// <summary>
    /// Данный класс нужен для того, чтобы добавлять/удалять/редактировать таблицы
    /// Кроме того, здесь есть функции для поиска элементов и полей, ссылающихся на конкретный элемент (нужны только Маше вроде)
    /// +функция, выдающая все атрибуты (названия) данной таблицы (нужна всем возможно), и все объекты данной таблицы (нужна всем), + все связи таблицы (на нее ссылаются, то есть таблица пользователей, а не машин)
    /// +функция, определяющая, есть ли жесткие связи ( ссылаются ли на данную таблицу кто-то другой с жесткой связью)
    /// +фунция для нахождение элемента в таблице по iD (видимому ID)
    /// +функции, которые выдаеют все атрибуты, которые ссылаются на данную таблицу по жесткой/любой связи
    /// +функция, возвращающая список таблиц, которые ссылаются на данную.
    /// зменения вносятся только Машей!
    /// </summary>
    public class PTable
    {
        /// <summary>
        /// Добавление таблицы
        /// </summary>
        /// <param name="p">Проект</param>
        /// <param name="name">Имя таблицы</param>
        /// <param name="db">Контейнер БД</param>
        public static bool Add(Project p, string name, ref Model1Container db, out string Message)
        {
            if (name == "" || name == null)
            {
                Message = "Введите название!";
                return false;
            }
            foreach (Table x in p.Table)
            {
                if (x.TableName == name)
                {
                    Message = "Уже существует таблица с таким названием";
                    return false;
                }
            }
            Table t = new Table();
            t.Project = p;
            t.TableName = name;
            t.CurrentID = 1;
            db.TableSet.Add(t);
            db.SaveChanges();
            Message = "";
            return true;
        }

        /// <summary>
        /// Удаление таблицы
        /// </summary>
        /// <param name="id">ID таблицы</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Удалось ли удалить таблицу, если не удалось. значит есть жесткие связи</returns>
        public static bool Delete(Int32 id, ref Model1Container db)
        {
            //ЕСЛИ НА ДАННУЮ ТАБЛИЦУ ССЫЛАЕТСЯ ДРУГАЯ ТАБЛИЦА, ТО ДАННУЮ ТАБЛИЦУ НЕЛЬЗЯ УДАЛИТЬ
            List<Connection> list2 = db.TableSet.Find(id).Connection.ToList();
            if (list2.Count > 0) return false;

            List<Example> list3 = db.TableSet.Find(id).Example.ToList();
            foreach (Example x in list3)
                PExample.Delete(x.IDExample, ref db);

            List<Attribute> list = db.TableSet.Find(id).Attribute.ToList();
            foreach (Attribute x in list)
            {
                PAttribute.Delete(x.IDAttribute, ref db);
            }

            db.TableSet.Remove(db.TableSet.Find(id));
            db.SaveChanges();
            return true;
        }

        /// <summary>
        /// Редактирование таблицы
        /// </summary>
        /// <param name="name">Новое имя</param>
        /// <param name="id">iD таблицы</param>
        /// <param name="db">Контейнер БД</param>
        public static void Edit(string name, Int32 id, ref Model1Container db)
        {
            db.TableSet.Find(id).TableName = name;
            db.SaveChanges();
        }

        /// <summary>
        /// Выдает список всех артибутов
        /// </summary>
        /// <param name="id">Id таблицы</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>список атрибутов</returns>
        public static List<Attribute> GetAttributes(Int32 id, ref Model1Container db)
        {
            List<Attribute> list = (from x in db.AttributeSet where x.Table.IDTable == id orderby x.IDAttribute select x).ToList();
            return list;
        }

        public static List<Attribute> GetKeyAttributes(Int32 id, ref Model1Container db)
        {
            List<Attribute> list = (from x in db.AttributeSet where x.Table.IDTable == id && x.IsKey orderby x.IDAttribute select x).ToList();
            return list;
        }

        /// <summary>
        /// Выдает список всех объектов таблицы
        /// </summary>
        /// <param name="id">iD таблицы</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns> список объектов</returns>
        public static List<Example> GetExamples(Int32 id, ref Model1Container db)
        {
            List<Example> list = (from x in db.ExampleSet where x.Table.IDTable == id orderby x.IDExample select x).ToList();
            return list;
        }

        /// <summary>
        /// Возвращает список всех связей (когда на таблицу ссылаются. т.е. для пользователей, а не для машин)
        /// </summary>
        /// <param name="id">iD таблицы</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Список связей</returns>
        public static List<Connection> GetConnections(Int32 id, ref Model1Container db)
        {
            List<Connection> list = (from x in db.ConnectionSet where x.Table.IDTable == id select x).ToList();
            return list;
        }

        /// <summary>
        /// Возвращет объект из таблицы, в котором видимый ID равен заданному
        /// </summary>
        /// <param name="tableID">Таблицы</param>
        /// <param name="ExampleID">Видимый ID объекта</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Объект</returns>
        public static Example GetExampleByID(Int32 tableID, Int32 ExampleID, ref Model1Container db)
        {
            List<Example> list = GetExamples(tableID, ref db);
            Example answer = (from x in list where x.VisibleID == ExampleID select x).First();
            return answer;
        }
        /// <summary>
        /// Имеются ли жесткие связи с данной таблицей? (на нее ссылаются)
        /// </summary>
        /// <param name="id">iD таблицы</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Есть ли жесткие связи?</returns>
        public static bool HaveHurdConnections(Int32 id, ref Model1Container db)
        {
            List<Connection> list = GetConnections(id, ref db);
            int i = (from x in list where x.IsHard select x).Count();
            if (i > 0) return true;
            return false;
        }

        /// <summary>
        /// Получение атрибутов, которые ссылаются на данную таблицу (iD пользователей машин)
        /// </summary>
        /// <param name="id">iD таблицы</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>список атрибутов</returns>
        public static List<Attribute> GetAllReferenceAttribute(Int32 id, ref Model1Container db)
        {
            List<Connection> list = GetConnections(id, ref db);
            List<Attribute> list2 = (from x in list select x.Attribute).ToList();
            return list2;

        }

        /// <summary>
        /// Получение атрибутов, которые ссылаются на данную таблицу с жесткой связью (iD пользователей машин)
        /// </summary>
        /// <param name="id">iD таблицы</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>список атрибутов</returns>
        public static List<Attribute> GetAllHurdReferenceAttribute(Int32 id,ref  Model1Container db)
        {
            List<Connection> list = (from x in GetConnections(id, ref db) where x.IsHard select x).ToList();
            List<Attribute> list2 = (from x in list select x.Attribute).ToList();
            return list2;

        }

        /// <summary>
        /// Получение таблиц, которые ссылаются на данную таблицу (машина)
        /// </summary>
        /// <param name="id">iD таблицы</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>список таблиц</returns>
        public static List<Table> GetAllReferenceTable(Int32 id, ref Model1Container db)
        {
            List<Connection> list = GetConnections(id, ref db);
            List<Table> list2 = (from x in list select x.Attribute.Table).ToList();
            return list2;
        }

        public static bool Check(Int32 id, ref Model1Container db)
        {
            List<Attribute> l = GetAttributes(id, ref db);
            foreach(Attribute x in l)
            {
                if (x.IsKey) return true;
            }
            return false;
        }
    }
}
