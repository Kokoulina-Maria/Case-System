﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseSystem.Model.PartialClasses
{
    class PProject
    {
        public static bool Add(string name, ref Model1Container db)
        {
            Project p = new Project();
            if (name == "" || name == null) return false;
            p.ProjectName = name;
            db.ProjectSet.Add(p);
            db.SaveChanges();
            return true;
        }

        public static void Edit(string name, Int32 id, ref Model1Container db)
        {
            db.ProjectSet.Find(id).ProjectName = name;
            db.SaveChanges();
        }
    }
}
