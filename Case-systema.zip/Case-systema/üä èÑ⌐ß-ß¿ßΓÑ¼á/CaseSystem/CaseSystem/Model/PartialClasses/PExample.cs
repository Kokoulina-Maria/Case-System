﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseSystem.Model.PartialClasses
{
    /// <summary>
    /// Данный класс нужен для того, чтобы добавлять/удалять/редактировать/проверять на логичность конкретные объекты
    /// Кроме того, он содержит функции для получения списка всех атрибутов данного объекта, списков всех объектов, которые ссылаются на данный объект: например, список всех машин владельца,
    /// + функции для получения списка полей, которые ссылаются на данный объект (все ID владельца в таблице Машин), 
    /// +списка всех объектов, которые ссылаются на данный объект с жесткой связью (например Университет - Комнаты),
    /// +для получения значения ключевого поля объекта (если оно одно) ВЫЗЫВАТЬ ТОЛЬКО В ТОМ СЛУЧАЕ, ЕСЛИ В ТАБЛИЦЕ ТОЛЬКО ОДИН КЛЮЧЕВОЙ АТРИБУТ, ИНАЧЕ БЕССМЫСЛЕНО.
    /// Кроме того, есть функции для определения, если ли объекты, которые ссылаются на данный и есть ли объекты, которые ссылаются на данный с жесткой связью.
    /// Изменения вносятся только Машей!
    /// </summary>
    public class PExample
    {
        /// <summary>
        /// Добавление объекта. МОЖЕТ ИСПОЛЬЗОВАТЬСЯ ЭЛИНОЙ И МАШЕЙ.
        /// </summary>
        /// <param name="atrib">Список атрибутов данного объекта. Еще не проверенный, проверяется в данной функции</param>
        /// <param name="e">Таблица, в которой находтся объект</param>
        /// <param name="errorMessage">Возвращаемое сообщение об ошибке, если результат false. Если результат true, то ""</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Возвращает значение false, если есть ошибки - в таком случае ни объект, ни атрибуты не добавляются. Причина ошибки в сообщении. Иначе возвращает true</returns>
        public static bool Add(List<Values> atrib, Table e, out string errorMessage, ref Model1Container db)
        {
            foreach (Values x in atrib)
            {
                if (!PValues.Check(x.Attribute.AttributeType, x.Content, x.Attribute.MaximumLength, x.Attribute.MaximumValue, x.Attribute.MinimumValue, x.Attribute.IsKey, out errorMessage, x.Attribute.IsRecuired))
                    return false;
                if (x.Attribute.AttributeType == "Подстановка" && !PValues.ExistReference(x.Attribute.Connection.Table, x.Content, x.Attribute.Connection.IsHard, ref db, out errorMessage)) return false;
            }
            Example o = new Example();
            o.Table = e;
            o.VisibleID = (int)e.CurrentID;
            db.TableSet.Find(e.IDTable).CurrentID++;
            db.ExampleSet.Add(o);
            db.SaveChanges();
            errorMessage = "";
            foreach (Values x in atrib)
            {
                PValues.Add(x.Content, x.Attribute, o, ref db);
            }
            string keys = GetAllKeyValues(o.IDExample, ref db);
            if (!CheckID(keys, ref db, o))
            {
                Delete(o.IDExample, ref db);
                errorMessage = "Элемент с таким ключом существует";
                return false;
            }
            return true;
        }

        /// <summary>
        /// Проверка, существует ли элемент с таким ключом уже в данной таблице. Нужен при добавлении. Вызывается изнутри функции добавления
        /// НЕ ИСПОЛЬЗОВАТЬ
        /// </summary>
        /// <param name="Keys">Строка, созданная из значений ключевых полей добавляемого объекта</param>
        /// <param name="db">Контейнер БД</param>
        /// <param name="e">Добавленный элемент</param>
        /// <returns>Можно ли добавить элемент</returns>
        public static bool CheckID(string Keys, ref Model1Container db, Example e)
        {
            foreach (Example x in db.TableSet.Find(e.Table.IDTable).Example)
            {
                if (Keys == GetAllKeyValues(x.IDExample, ref db) && e.IDExample!=x.IDExample) return false;
            }
            return true;
        }

        /// <summary>
        /// Изменение объекта. МОЖЕТ ИСПОЛЬЗОВАТЬСЯ ЭЛИНОЙ И МАШЕЙ.
        /// </summary>
        /// <param name="id">ID в нашей БД объекта</param>
        /// <param name="atrib">Список атрибутов данного объекта. Еще не проверенный, проверяется в данной функции</param>
        /// <param name="errorMessage">Возвращаемое сообщение об ошибке, если результат false. Если результат true, то ""</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Возвращает значение false, если есть ошибки - в таком случае атрибуты не редактируются. Причина ошибки в сообщении. Иначе возвращает true</returns>
        public static bool Change(Int64 id, List<Values> atrib, out string errorMessage, ref Model1Container db)
        {
            int i = 0;
            foreach (Values x in atrib)
            {
                if (!PValues.Check(x.Attribute.AttributeType, x.Content, x.Attribute.MaximumLength, x.Attribute.MaximumValue, x.Attribute.MinimumValue, x.Attribute.IsKey, out errorMessage, x.Attribute.IsRecuired))
                    return false;
                if (!PValues.CheckReference(x.IDValue, x.Content, x.Attribute, db.ExampleSet.Find(id), ref db, out errorMessage))
                    return false;
                if (x.Attribute.AttributeType == "Подстановка" && !PValues.ExistReference(x.Attribute.Connection.Table, x.Content, x.Attribute.Connection.IsHard, ref db, out errorMessage))
                    return false;
                if (x.Attribute.IsKey && HaveReferences(id, ref db) && x.Content == "null")
                {
                    errorMessage = "На данный объект есть ссылка, его ключевое поле не может принимть значения null";
                    return false;
                }
                //если на данный объект ссылаются, нужно изменить значение всех внешних ключей, которые ссылаютс яна данный объект
                if (x.Attribute.IsKey && HaveReferences(id, ref db))
                {
                    List<Values> s = GetAllReferenceValues(id, ref db);
                    foreach (Values j in s)
                    {
                        PValues.Change(j.IDValue, x.Content, ref db);
                    }
                }
                List<Values> list = GetAttributes(id, ref db);
                Values v = (from j in list where j.Attribute.IDAttribute == x.Attribute.IDAttribute select j).First();
                PValues.Change(v.IDValue, x.Content, ref db);
            }
            errorMessage = "";
            return true;
        }

        /// <summary>
        /// Возвращает список значений атрибутов данного объекта (полей)
        /// </summary>
        /// <param name="id">ID в нашей БД данного объекта</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Список полей</returns>
        public static List<Values> GetAttributes(Int64 id, ref Model1Container db)
        {
            List<Values> list = (from x in db.ValuesSet where x.Example.IDExample == id select x).ToList();
            return list;
        }
        /// <summary>
        /// Возвращает значение первого ключевого поля. БЕСПОЛЕЗНА если их несколько. Маше нужна, остальным по необходимости
        /// </summary>
        /// <param name="id">ID в нашей БД данного объекта</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Значение ключевого поля</returns>
        public static string GetKeyValue(Int64 id, ref Model1Container db)
        {
            List<Values> list = GetAttributes(id, ref db);
            string value = (from x in list where x.Attribute.IsKey select x.Content).First();
            return value;
        }

        /// <summary>
        /// Возвращает значение всех ключевых полей одной строкой. Маше нужна, чтобы проверять, нет ли в таблице уже объекта стаким же ключом, остальным по необходимости
        /// </summary>
        /// <param name="id">ID в нашей БД данного объекта</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Строка, объединяющая значения всех ключевых полей</returns>
        public static string GetAllKeyValues(Int64 id, ref Model1Container db)
        {
            List<Values> list = GetAttributes(id, ref db);
            List<String> list2 = (from x in list where x.Attribute.IsKey orderby x.Attribute.IDAttribute select x.Content).ToList();
            string result = "";
            foreach (string x in list2)
                result = result + x;
            return result;
        }

        /// <summary>
        /// Возвращает список всех объектов, которые ссылаются на данный объект: Например список всех машин, которыми владеет человек.
        /// Очень нужная функция, например для Элины - при выводе данныех подчинённых таблиц (в виде гридов)
        /// </summary>
        /// <param name="id">ID в нашей БД данного объекта</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Список объектов</returns>
        public static List<Example> GetAllReferenceExample(Int64 id, ref Model1Container db)
        {
            List<Attribute> list = PTable.GetAllReferenceAttribute(db.ExampleSet.Find(id).Table.IDTable, ref db);
            List<Example> list2=new List<Example>();
            foreach (Attribute x in list)
            {
                list2.AddRange(PAttribute.GetAllReferenceObjects(x.IDAttribute, GetKeyValue(id, ref db), ref db));
            }
            return list2;
        }

        /// <summary>
        /// Возвращает список всех полей, которые ссылаются на данный объект. Например: значение ID владельца в таблице машин.
        /// Используется только МАШЕЙ (скорее всего), так как данная функция нужна только для удаления объекта. 
        /// Если у объекта есть нежесткие связи, то знаечния данных полей поле его удаления станут раными null.
        /// </summary>
        /// <param name="id">ID в нашей БД данного объекта</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Список значений полей объектов</returns>
        public static List<Values> GetAllReferenceValues(Int64 id, ref Model1Container db)
        {
            List<Attribute> list = PTable.GetAllReferenceAttribute(db.ExampleSet.Find(id).Table.IDTable, ref db);
            List<Values> list2 = new List<Values>();
            foreach (Attribute x in list)
            {
                list2.AddRange(PAttribute.GetAllReferenceValues(x.IDAttribute, GetKeyValue(id, ref db), ref db));
            }
            return list2;
        }

        /// <summary>
        /// Возвращает список всех объектов, которые ссылаются на данный объект с жесткой связью: Например список всех комнат в здании.
        /// Функция нужна только Маше, чтобы узнать, можно ли удалять объект.
        /// </summary>
        /// <param name="id">ID в нашей БД данного объекта</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Список объектов</returns>
        public static List<Example> GetAllHurdReferenceExample(Int64 id, ref Model1Container db)
        {
            List<Attribute> list = PTable.GetAllHurdReferenceAttribute(db.ExampleSet.Find(id).Table.IDTable, ref db);
            List<Example> list2 = new List<Example>();
            foreach (Attribute x in list)
            {
                list2.AddRange(PAttribute.GetAllReferenceObjects(x.IDAttribute, GetKeyValue(id, ref db), ref db));
            }
            return list2;
        }

        /// <summary>
        /// Проверка, есть ли объекты, ссылающиеся на данный: Например, есть ли у человека машины.
        /// Нужна, например, Элине, чтобы определить, нужно ли вообще выводить глиды для подчиненных элементов.
        /// </summary>
        /// <param name="id">ID в нашей БД данного объекта</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Список объектов</returns>
        public static bool HaveReferences(Int64 id, ref Model1Container db)
        {
            if (PTable.GetConnections(db.ExampleSet.Find(id).Table.IDTable, ref db).Count>0)
            {
                List<Example> list = GetAllReferenceExample(id, ref db);
                if (list.Count() > 0)
                    return true;
                else return false;
            }
            else return false;
        }

        /// <summary>
        /// Проверка, есть ли объекты, ссылающиеся на данный с жесткой связью: Например, есть ли у здания комнаты
        /// Нужна только Маше для того, чтобы узнать, можно ли удалять данный объект.
        /// </summary>
        /// <param name="id">ID в нашей БД данного объекта</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Список объектов</returns>
        public static bool HaveHurdReferences(Int64 id, ref Model1Container db)
        {
            if (PTable.HaveHurdConnections(db.ExampleSet.Find(id).Table.IDTable, ref db))
            {
                List<Example> list = GetAllHurdReferenceExample(id, ref db);
                if (list.Count() > 0)
                    return true;
                else return false;
            }
            else return false;
        }

        /// <summary>
        /// Удаление объекта. Можно использовать только Маше и Элине.
        /// Значения всех ссылающихся на него полей становится равным null. 
        /// Если у объекта есть ссылающиеся а него объекты с жесткой связью, объект удалить нельзя.
        /// </summary>
        /// <param name="id">ID в нашей БД данного объекта</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Удалось ли удалить объект</returns>
        public static bool Delete(Int64 id, ref  Model1Container db)
        {
            if (!HaveHurdReferences(id, ref db))
            {
                List<Values> list = db.ExampleSet.Find(id).Values.ToList();
                if (HaveReferences(id, ref db))
                {
                    List<Values> l = GetAllReferenceValues(id, ref db);
                    foreach (Values x in l)
                        db.ValuesSet.Find(x.IDValue).Content = "null";
                    db.SaveChanges();
                }
                foreach (Values x in list)
                    PValues.Delete(x.IDValue, ref db);               
                db.ExampleSet.Remove(db.ExampleSet.Find(id));
                db.SaveChanges();
                return true;
            }
            else return false;
        }
    }
}
