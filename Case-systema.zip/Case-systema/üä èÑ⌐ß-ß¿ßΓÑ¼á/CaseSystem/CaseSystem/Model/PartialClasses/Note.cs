﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseSystem.Model.PartialClasses
{
    public class Note
    {
        private List<Note> ends;

        public Note Prev { get; set; }
        public Table Info { get; set; }
        public List<Note> Ends
        {
            get
            {
                return ends;
            }
        }
        public bool Use { get; set; }


        public Note()
        {
            Prev = null;
            ends = new List<Note>();
            Use = false;
        }

        public Note(Note beg, Table info)
        {
            Prev = beg;
            Info = info;
            Use = false;
            ends = new List<Note>();
        }

        public Note(Note beg, Table _info, bool use)
        {
            Prev = beg;
            Info = _info;
            Use = use;
            ends = new List<Note>();
        }

        public Note(Table _beg, bool useAt, Table first, bool useTab)
        {
            Info = _beg;
            Use = useAt;
            ends = new List<Note>();
            Ends.Add(new Note(this, first, useTab));
        }

        public void Add(Note note)
        {
            Ends.Add(note);
        }

        public void Add(Table table)
        {
            Ends.Add(new Note(this, table));
        }

        public void Add(Table table, bool use)
        {
            Ends.Add(new Note(this, table, use));
        }

        public void Delete(Note note)
        {
            Ends.Remove(note);
        }
    }
}
