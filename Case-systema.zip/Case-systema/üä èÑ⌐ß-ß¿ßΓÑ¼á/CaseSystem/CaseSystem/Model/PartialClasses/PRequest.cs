﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CaseSystem.Model.PartialClasses
{
    public class PRequest
    {
        private static List<Table> mainTabs;

        public static Request Create(ref Model1Container db, Project p, string name, Attribute att, string cond)
        {
            Request rq = new Request();
            rq.RequestName = name;

            ReqElement elem = new ReqElement();
            elem.Attribute = att;
            string sign = "";
            sign += cond[0];
            elem.Sign = sign;
            elem.Condition = cond.Substring(1);
            rq.ReqElement.Add(elem);

            db.RequestSet.Add(rq);
            db.SaveChanges();
            return rq;
        }

        public static void Add(ref Model1Container db, Request rq, Attribute att, string cond)
        {
            ReqElement elem = new ReqElement();
            elem.Attribute = att;
            string sign = "";
            sign += cond[0];
            elem.Sign = sign;
            elem.Condition = cond.Substring(1);
            rq.ReqElement.Add(elem);

            db.ReqElementSet.Add(elem);
            db.SaveChanges();
        }

        public static void Delete(ref Model1Container db, Request rq)
        {
            while (rq.ReqElement.Count > 0)
                db.ReqElementSet.Remove(rq.ReqElement.First());
            db.RequestSet.Remove(rq);
            db.SaveChanges();
        }

        public static void Reqursi(ref Note sch, Table atT, Table tab, ref bool ok)
        {
            if (sch.Info == null || (sch.Ends.Count > 0 && sch.Info.IDTable != atT.IDTable))
            {
                for (int i = 0; i < sch.Ends.Count; i++)
                {
                    Note x = sch.Ends[i];
                    Reqursi(ref x, atT, tab, ref ok);
                    if (ok) sch.Ends[i] = x;
                    break;
                }
            }

            else if (sch.Ends.Count > 0)
            {
                ok = true;
                bool useTab = false;
                foreach (Table table in mainTabs)
                {
                    if (tab.IDTable == table.IDTable) useTab = true;
                }
                sch.Add(tab, useTab);
            }
        }


        public static DataGridView Func(Model1Container db, List<object[]> con)
        {

            #region // Список необходимых таблиц и список атрибутов 
            mainTabs = new List<Table>();
            List<Attribute> mainAtts = new List<Attribute>();
            foreach (object[] row in con)
            {
                mainTabs.Add((Table)row[0]);
                mainAtts.Add((Attribute)row[1]);
            }

            #endregion

            #region // Создание схемы данных

            #region // Схема связи таблиц в базе данных
            // Вершина схемы всегда остается пустой для тех случаев, 
            // когда нет записей, в которые можно добавить таблицу
            #endregion
            Note schedule = new Note();

            #region // Создаем схему по связям
            foreach (Connection conn in db.ConnectionSet)
            {
                bool ugu = false;
                Reqursi(ref schedule, conn.Attribute.Table, conn.Table, ref ugu);


                if (!ugu)
                {
                    bool useAt = false;
                    bool useTab = false;
                    foreach (Table table in mainTabs)
                    {
                        if (conn.Attribute.Table.IDTable == table.IDTable) useAt = true;
                        if (conn.Table.IDTable == table.IDTable) useTab = true;
                    }
                    Note note = new Note(schedule, conn.Attribute.Table, useAt);
                    note.Add(conn.Table, useTab);
                    schedule.Add(note);
                }
            }
            #endregion

            #region // Проверяем, можно ли сократить количество вершин в схеме
            List<Note> peeks = new List<Note>();
            peeks = schedule.Ends;
            foreach (Note x in peeks)
            {
                Queue<Note> notes = new Queue<Note>();
                Note note = new Note();

                if (schedule.Ends.Count > 1)
                {
                    // Добавляем в очередь список таблиц из начала схемы
                    foreach (Note xx in schedule.Ends)
                        if (xx != x) notes.Enqueue(xx);

                    // Пока очередь не опустеет или не найдем нужную вершину (таблицу в вершине)
                    // Добавляем концы текущей вершины в очередь
                    while (notes.Count > 0 && notes.Peek().Info != x.Info)
                    {
                        note = notes.Dequeue();
                        foreach (Note el in note.Ends)
                            notes.Enqueue(el);
                    }

                    // Если находим нужную вершину, добавляем в нее текущую ветку схемы
                    // и удаляем из вершины схемы
                    if (notes.Count != 0)
                    {
                        note.Add(x);
                        schedule.Delete(x);
                    }
                }


            }
            #endregion

            #endregion

            #region // Удаление неиспользуемых таблиц из схемы

            // Создаем стек записей для удаления неиспользуемых таблиц
            Queue<Note> curNotes = new Queue<Note>();
            Stack<Note> allNotes = new Stack<Note>();

            // Добавляем в стек список таблиц из начала схемы
            foreach (Note x in schedule.Ends)
            {
                curNotes.Enqueue(x);
                allNotes.Push(x);
            }

            // Пока очередь не опустеет добавляем концы текущей вершины в стек
            while (curNotes.Count > 0)
            {
                foreach (Note el in curNotes.Dequeue().Ends)
                {
                    curNotes.Enqueue(el);
                    allNotes.Push(el);
                }

            }

            while (allNotes.Count > 0)
            {
                Note cur = allNotes.Pop();
                Note prev = cur.Prev;
                if (cur.Ends.Count == 0 && !cur.Use) prev.Delete(cur);
            }
            #endregion


            #region // Добавляем в сводную таблицу строки из выбранных таблиц
            if (schedule.Ends.Count != 1) return null;

            List<string> nameCol = new List<string>();
            List<List<Example>> ur = new List<List<Example>>();
            DataGridView dgv = new DataGridView();
            Queue<Note> tables = new Queue<Note>();

            // Добавляем в стек список таблиц из начала схемы
            foreach (Note x in schedule.Ends[0].Ends)
            {
                tables.Enqueue(x);
            }

            nameCol.Add(schedule.Ends[0].Info.TableName);
            dgv.Columns.Add(schedule.Ends[0].Info.TableName, schedule.Ends[0].Info.TableName);

            Example[] exam = new Example[1];
            foreach (Example ex in schedule.Ends[0].Info.Example)
            {
                ur.Add(new List<Example>());
                dgv.Rows.Add();
                dgv[0, dgv.RowCount - 1].Value = ex;
                ur[ur.Count - 1].Add(ex);
            }

            while (tables.Count > 0)
            {
                Note cur = tables.Dequeue();
                foreach (Note x in cur.Ends)
                    tables.Enqueue(x);

                nameCol.Add(cur.Info.TableName);
                dgv.Columns.Add(cur.Info.TableName, cur.Info.TableName);
                int colTab = nameCol.IndexOf(cur.Info.TableName);
                int colAt = nameCol.IndexOf(cur.Prev.Info.TableName);

                Attribute att = new Attribute();
                foreach (Connection conn in cur.Info.Connection)
                {
                    if (cur.Prev.Info.Attribute.Contains(conn.Attribute)) att = conn.Attribute;
                }
                for (int i = 0; i < dgv.RowCount; i++)
                {
                    foreach (Values val in ((Example)dgv[colAt,i].Value).Values)
                    {
                        if (val.Attribute.IDAttribute == att.IDAttribute)
                        {
                            int idEx = int.Parse(val.Content);
                            foreach (Example x in PTable.GetExamples(cur.Info.IDTable, ref db))
                                if (x.IDExample == idEx)
                                {
                                    ur[i].Add(x);
                                    dgv[i, colTab].Value = x;
                                }
                        }
                    }

                }
            }

            #endregion

            #region // Выбор только нужных атрибутов
            DataGridView fullResult = new DataGridView();
            List<bool> ok = new List<bool>();

            fullResult.Columns.Add("check", "check");
            fullResult.AllowUserToAddRows = false;


            for (int j = 0; j < dgv.RowCount; j++)
            {
                fullResult.Rows.Add();
                ok.Add(true);
            }
            for (int i = 0; i < con.Count; i++)
            {
                Attribute curAtt = (Attribute)con[i][1];
                int indTab = nameCol.IndexOf(((Table)con[i][0]).TableName);
                fullResult.Columns.Add(curAtt.AttributeName, curAtt.AttributeName);
                if (fullResult.Columns.Contains("check")) fullResult.Columns.Remove("check");
                int indAt = fullResult.Columns[curAtt.AttributeName].Index;


                for (int k = 0; k < dgv.RowCount; k++)
                    foreach (Values val in ((Example)dgv[indTab, k].Value).Values)
                    {
                        if (val.Attribute.IDAttribute == curAtt.IDAttribute)
                        {
                            fullResult[indAt, k].Value = val.Content;
                            ok[k] = GetInType(val.Attribute.AttributeType, val.Content, ((string)con[i][2]).Substring(1), ((string)con[i][2])[0]);
                        }
                    }



                //foreach (Values val in ur[i][colAt].Values)
                //{
                //    if (val.Attribute.IDAttribute == att.IDAttribute)
                //    {
                //        int idEx = int.Parse(val.Content);
                //        foreach (Example x in PTable.GetExamples(cur.Info.IDTable, ref db))
                //            if (x.IDExample == idEx) ur[i].Add(x);
                //    }
                //}
            }

            for (int i = fullResult.RowCount - 1; i >= 0; i--)
            {
                if (!ok[i]) fullResult.Rows.RemoveAt(i);
            }

            //for (int i = 0; i < fullResult.RowCount - 2; i++)
            //{
            //    for (int j = fullResult.RowCount - 1; j > i; j--)
            //    {
            //        if ()
            //    }
            //}

            #endregion
            return fullResult;
        }


        private static bool GetInType(string type, string tabEl, string valEl, char sym)
        {
            switch (type)
            {
                case "string":
                    return Eq(tabEl, valEl, sym);
                case "double":
                    return Eq(double.Parse(tabEl), double.Parse(valEl), sym);
                case "DateTime":
                    return Eq(DateTime.Parse(tabEl), DateTime.Parse(valEl), sym);
                case "bool":
                    return Eq(bool.Parse(tabEl), bool.Parse(valEl), sym);
                default:
                    return Eq(int.Parse(tabEl), int.Parse(valEl), sym);
            }
        }

        private static bool Eq(string tabEl, string valEl, char sym)
        {
            switch (sym)
            {
                case '=':
                    return tabEl == valEl;
                default:
                    return tabEl != valEl;
            }
        }

        private static bool Eq(double tabEl, double valEl, char sym)
        {
            switch (sym)
            {
                case '>':
                    return tabEl > valEl;
                case '<':
                    return tabEl < valEl;
                case '=':
                    return tabEl == valEl;
                default:
                    return tabEl != valEl;
            }
        }

        private static bool Eq(DateTime tabEl, DateTime valEl, char sym)
        {
            switch (sym)
            {
                case '>':
                    return tabEl > valEl;
                case '<':
                    return tabEl < valEl;
                case '=':
                    return tabEl == valEl;
                default:
                    return tabEl != valEl;
            }
        }

        private static bool Eq(bool tabEl, bool valEl, char sym)
        {
            switch (sym)
            {
                case '=':
                    return tabEl == valEl;
                default:
                    return tabEl != valEl;
            }
        }

        private static bool Eq(int tabEl, int valEl, char sym)
        {
            switch (sym)
            {
                case '>':
                    return tabEl > valEl;
                case '<':
                    return tabEl < valEl;
                case '=':
                    return tabEl == valEl;
                default:
                    return tabEl != valEl;
            }
        }



        //public static DataTable Func(Model1Container db, DataTable cond)
        //{

        //    #region // Список необходимых таблиц и список атрибутов 
        //    List<Table> mainTabs = new List<Table>();
        //    List<Attribute> mainAtts = new List<Attribute>();
        //    foreach (DataRow row in cond.Rows)
        //    {
        //        mainTabs.Add((Table)row[0]);
        //        mainAtts.Add((Attribute)row[1]);
        //    }

        //    #endregion

        //    #region // Создание схемы данных

        //    #region // Схема связи таблиц в базе данных
        //    // Вершина схемы всегда остается пустой для тех случаев, 
        //    // когда нет записей, в которые можно добавить таблицу
        //    #endregion
        //    Note schedule = new Note();

        //    #region // Создаем схему по связям
        //    foreach (Connection conn in db.ConnectionSet)
        //    {
        //        Queue<Note> notes = new Queue<Note>();
        //        Note note = new Note();

        //        // Добавляем в очередь список таблиц из начала схемы
        //        foreach (Note x in schedule.Ends)
        //            notes.Enqueue(x);

        //        // Пока очередь не опустеет или не найдем нужную вершину (таблицу в вершине)
        //        // Добавляем концы текущей вершины в очередь
        //        while (notes.Count > 0 && notes.Peek().Info != conn.Attribute.Table)
        //        {
        //            note = notes.Dequeue();
        //            foreach (Note el in note.Ends)
        //                notes.Enqueue(el);
        //        }

        //        // Если не находим нужной вершины, добавляем в начало схемы
        //        // иначе в найденную вершину добавляем еще один конец
        //        if (notes.Count == 0)
        //        {
        //            bool useAt = false;
        //            bool useTab = false;
        //            foreach (Table table in mainTabs)
        //            {
        //                if (conn.Attribute.Table.IDTable == table.IDTable) useAt = true;
        //                if (conn.Table.IDTable == table.IDTable) useTab = true;
        //            }
        //            schedule.Add(new Note(conn.Attribute.Table, useAt, conn.Table, useTab));

        //        }
        //        else note.Add(conn.Table);
        //    }
        //    #endregion

        //    #region // Проверяем, можно ли сократить количество вершин в схеме
        //    List<Note> peeks = new List<Note>();
        //    peeks = schedule.Ends;
        //    foreach (Note x in peeks)
        //    {
        //        Queue<Note> notes = new Queue<Note>();
        //        Note note = new Note();

        //        if (schedule.Ends.Count > 1)
        //        {
        //            // Добавляем в очередь список таблиц из начала схемы
        //            foreach (Note xx in schedule.Ends)
        //                if (xx != x) notes.Enqueue(xx);

        //            // Пока очередь не опустеет или не найдем нужную вершину (таблицу в вершине)
        //            // Добавляем концы текущей вершины в очередь
        //            while (notes.Count > 0 && notes.Peek().Info != x.Info)
        //            {
        //                note = notes.Dequeue();
        //                foreach (Note el in note.Ends)
        //                    notes.Enqueue(el);
        //            }

        //            // Если находим нужную вершину, добавляем в нее текущую ветку схемы
        //            // и удаляем из вершины схемы
        //            if (notes.Count != 0)
        //            {
        //                note.Add(x);
        //                schedule.Delete(x);
        //            }
        //        }


        //    }
        //    #endregion

        //    #endregion

        //    #region // Удаление неиспользуемых таблиц из схемы

        //    // Создаем стек записей для удаления неиспользуемых таблиц
        //    Queue<Note> curNotes = new Queue<Note>();
        //    Stack<Note> allNotes = new Stack<Note>();

        //    // Добавляем в стек список таблиц из начала схемы
        //    foreach (Note x in schedule.Ends)
        //    {
        //        curNotes.Enqueue(x);
        //        allNotes.Push(x);
        //    }

        //    // Пока очередь не опустеет добавляем концы текущей вершины в стек
        //    while (curNotes.Count > 0)
        //    {
        //        foreach (Note el in curNotes.Dequeue().Ends)
        //        {
        //            curNotes.Enqueue(el);
        //            allNotes.Push(el);
        //        }

        //    }

        //    while (allNotes.Count > 0)
        //    {
        //        Note cur = allNotes.Pop();
        //        Note prev = cur.Prev;
        //        if (cur.Ends.Count == 0 && !cur.Use) prev.Delete(cur);
        //    }
        //    #endregion


        //    #region // Добавляем в сводную таблицу строки из выбранных таблиц
        //    if (schedule.Ends.Count != 1) return null;

        //    DataTable result = new DataTable();
        //    Queue<Note> tables = new Queue<Note>();

        //    // Добавляем в стек список таблиц из начала схемы
        //    foreach (Note x in schedule.Ends[0].Ends)
        //    {
        //        tables.Enqueue(x);
        //    }

        //    result.Columns.Add(schedule.Ends[0].Info.TableName);


        //    object[] exam = new object[1];
        //    foreach (Example ex in schedule.Ends[0].Info.Example)
        //    {
        //        result.Rows.Add();
        //        exam[0] = ex;
        //        result.Rows[0].ItemArray = exam;
        //    }

        //    while (tables.Count > 0)
        //    {
        //        Note cur = tables.Dequeue();
        //        foreach (Note x in cur.Ends)
        //            tables.Enqueue(x);
        //        result.Columns.Add(cur.Info.TableName);
        //        int colTab = result.Columns.IndexOf(cur.Info.TableName);
        //        int colAt = result.Columns.IndexOf(cur.Prev.Info.TableName);
        //        Attribute att = new Attribute();
        //        foreach (Connection conn in cur.Info.Connection)
        //        {
        //            if (cur.Prev.Info.Attribute.Contains(conn.Attribute)) att = conn.Attribute;
        //        }
        //        for (int i = 0; i < result.Rows.Count; i++)
        //        {
        //            exam = new object[result.Columns.Count];
        //            exam = result.Rows[i].ItemArray;
        //            int idEx = (int)exam[colAt];
        //            exam[colTab] = PTable.GetExamples(cur.Info.IDTable, ref db)[idEx];
        //            result.Rows[i].ItemArray = exam;
        //        }
        //    }
        //    #endregion

        //    #region // Выбор только нужных атрибутов
        //    DataTable fullResult = new DataTable();
        //    List<bool> ok = new List<bool>();

        //    for (int j = 0; j < result.Rows.Count; j++)
        //    {
        //        fullResult.Rows.Add();
        //        ok.Add(true);
        //    }

        //    for (int i = 0; i < cond.Rows.Count; i++)
        //    {
        //        Attribute curAtt = (Attribute)cond.Rows[i].ItemArray[1];
        //        int indTab = result.Columns.IndexOf(curAtt.Table.TableName);
        //        fullResult.Columns.Add(curAtt.AttributeName);
        //        int indAt = fullResult.Columns.IndexOf(curAtt.AttributeName);

        //        for (int j = 0; j < result.Rows.Count; j++)
        //        {
        //            exam = new object[result.Columns.Count];
        //            exam = result.Rows[i].ItemArray;
        //            Example ex = (Example)result.Rows[i].ItemArray[indTab];
        //            foreach (Values val in ex.Values)
        //            {
        //                if (val.Attribute.IDAttribute == curAtt.IDAttribute)
        //                {
        //                    fullResult.Rows[j].ItemArray[indAt] = val.Content;
        //                    switch ()
        //                    if (val.Content)
        //                }

        //            }

        //        }
        //    }

        //    #endregion



        //    return fullResult;
        //}


    }
}
