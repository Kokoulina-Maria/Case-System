﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseSystem.Model.PartialClasses
{
    /// <summary>
    /// Данный класс нужен для того, чтобы добавлять/удалять/редактировать/проверять на логичность связи между таблицами (таблицей и атрибутом)
    /// Изменения вносятся только Машей!
    /// </summary>
    class PConnection
    {
        /// <summary>
        /// Добавление связи. НЕ ИСПОЛЬЗОВАТЬ! Перед этим вызови: 1. проверку 2. сохранение атрибута 
        /// </summary>
        /// <param name="a">Атрибут (который ссылается) - *</param>
        /// <param name="e">Таблица (на которую ссылаются) - 1 или 0..1</param>
        /// <param name="isHurd">Жесткая связь или нет (1 или 0..1)</param>
        /// <param name="db">Контейнер БД</param>
        public static void Add(Attribute a, Table e, bool isHurd, ref Model1Container db)
        {
            Connection x = new Connection();
            x.Attribute = a;
            x.Table = e;
            x.IsHard = isHurd;
            db.ConnectionSet.Add(x);
            db.SaveChanges();
        }

        /// <summary>
        /// Изменение типа связи. НЕ ИСПОЛЬЗОВАТЬ!
        /// </summary>
        /// <param name="id">ID связи в нашей БД</param>
        /// <param name="isHurd">Новое значение жесткости</param>
        /// <param name="db">Контейнер БД</param>
        public static void Change(Int64 id, bool isHurd, ref Model1Container db)
        {
            db.ConnectionSet.Find(id).IsHard = isHurd;
            Attribute a = db.ConnectionSet.Find(id).Attribute;
            if (isHurd)
            {
                List<Values> l = (from v in db.ValuesSet where v.Attribute.IDAttribute == a.IDAttribute && v.Content == "null" select v).ToList();
                foreach (Values v in l) PExample.Delete(v.Example.IDExample, ref db);
            }
            db.SaveChanges();
        }

        /// <summary>
        /// Удаление связиВызывается только при удалении атрибута или таблицы. НЕ ИСПОЛЬЗОВАТЬ!
        /// </summary>
        /// <param name="id">D связи в нашей БД</param>
        /// <param name="db">Контейнер БД</param>
        public static void Delete(Int64 id, ref Model1Container db)
        {
            db.ConnectionSet.Remove(db.ConnectionSet.Find(id));
            db.SaveChanges();
        }

        /// <summary>
        /// Проверка, можно ли добавить связь: один ли в таблице ключ, не ссылается ли таблица на саму себя
        /// </summary>
        /// <param name="e">Таблица, на которую ссылаются (человек, а не машина)</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Можно ли провести связь</returns>
        public static bool Check(Table e, ref Model1Container db, out string message)
        {
            List<Attribute> list = PTable.GetAttributes(e.IDTable, ref db);
            List<Attribute> v = (from j in list where j.IsKey select j).ToList();
            if (v.Count != 1)
            {
                message = "У таблицы, на которую ссылается данный атрибут, составной ключ! На нее не может ссылаться другая таблица";
                return false;
            }
            message = "";
            return true;
        }
    }
}
