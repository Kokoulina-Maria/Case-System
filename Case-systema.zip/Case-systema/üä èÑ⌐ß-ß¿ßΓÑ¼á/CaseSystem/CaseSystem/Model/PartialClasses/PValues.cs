﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseSystem.Model.PartialClasses
{
    /// <summary>
    /// Данный класс нужен для того, чтобы добавлять/удалять/редактировать/проверять на логичность конкретные поля объектов
    /// Изменения вносятся только Машей!
    /// </summary>
    public class PValues       
    {
        /// <summary>
        /// Добавление значения атрибута. ПРОСТО ТАК НЕ ИСПОЛЬЗОВАТЬ. Должна вызываться из класса PExample при добавлении объекта.
        /// </summary>
        /// <param name="value">Значение поля</param>
        /// <param name="a">Атрибут, который задает это поле</param>
        /// <param name="o">Объект, которому принадлежит это поле</param>
        /// <param name="db">Контейнер с БД</param>
        public static void Add(string value, Attribute a, Example o, ref Model1Container db)
        {
            Values v = new Values();
            if (a.AttributeType != "Счетчик") {
                if ((value == null || value == "")) value = " ";
                v.Content = value;              
            }
            else v.Content = o.VisibleID + "";
            v.Attribute = db.AttributeSet.Find(a.IDAttribute);
            v.Example = db.ExampleSet.Find(o.IDExample);
            db.ValuesSet.Add(v);
            db.SaveChanges();
        }

        /// <summary>
        /// Редактирование значения атрибута. ПРОСТО ТАК НЕ ИСПОЛЬЗОВАТЬ. Должна вызываться из класса PExample при редактировании объекта.
        /// </summary>
        /// <param name="id">ID в нашей БД метаданных данного поля</param>
        /// <param name="value">Новое значение поля</param>
        /// <param name="db">Контейнер БД</param>
        public static void Change(Int64 id, string value, ref Model1Container db)
        {
            db.ValuesSet.Find(id).Content = value;
            db.SaveChanges();
        }

        /// <summary>
        /// Удаление значения атрибута. Вообще НЕ ВЫЗЫВАТЬ ДАННЫЙ МЕТОД! Должен вызываться только из классов PExample при удалении объекта и из класса PAttribute при удалении всего атрибута в таблице.
        /// </summary>
        /// <param name="id">ID в нашей БД метаданных данного поля</param>
        /// <param name="db">Контейнер БД</param>
        public static void Delete(Int64 id, ref Model1Container db)
        {
            db.ValuesSet.Remove(db.ValuesSet.Find(id));
            db.SaveChanges();
        }

        /// <summary>
        /// Проверка, не ссылается ли объект сам на себя
        /// </summary>
        /// <param name="id">ID значения атрибута объекта</param>
        /// <param name="value">значение атрибута объекта</param>
        /// <param name="a">артибут</param>
        /// <param name="e">объект</param>
        /// <param name="db">контейнер БД</param>
        /// <returns></returns>
        public static bool CheckReference(Int64 id, string value, Attribute a, Example e, ref Model1Container db, out string Message)
        {
            Message = "";
            //таблица не может ссылаться на саму себя
            if (a.AttributeType == "Подстановка" && a.Connection.Table.IDTable == e.Table.IDTable && value == PExample.GetKeyValue(e.IDExample, ref db))
            {
                Message = "Объект не может ссылаться на самого себя";
                return false;
            }
            else return true;
        }
        /// <summary>
        /// Проверка, существует ли объект, на который ссылается данный объект
        /// </summary>
        /// <returns></returns>
        public static bool ExistReference(Table t, string value, bool ishurd, ref Model1Container db, out string m)
        {
            m = "";
            if (value == "null")
            {
                if (ishurd)
                {
                    m = "Связь жесткая. Укажите значение!";
                    return false;
                }
                else return true;
            }
            else
            {
                List<Example> l = t.Example.ToList();
                foreach (Example x in l)
                {
                    string s=PExample.GetKeyValue(x.IDExample, ref db);
                    if (s == value) return true;
                }
                m = "В таблице не существует элемента с таким ключом";
                return false;
            }
        }

        /// <summary>
        /// Проверка значения атрибута на логичность: не соответствие значения типу атрибута, не больше ли указанной длины, не превышает ли максимум и минимум...
        /// Данная функция вызывается перед добавлением значения атрибута, перед редактированием значения атрибута из класса PExample.
        /// Кроме того, при удалении атрибута из таблицы, для того, чтобы удалить все поля, не соответствующие новым правилам.
        /// Данный метод НЕ ИСПОЛЬЗОВАТЬ
        /// </summary>
        /// <param name="type">Тип атрибута (строка, число, ссылка...)</param>
        /// <param name="value">Значение поля конкретного объекта</param>
        /// <param name="length">Максимальная допустимая длина</param>
        /// <param name="max">Максимальное значение</param>
        /// <param name="min">Минимальное значение</param>
        /// <param name="isKey">Евляется ли ключевым полем</param>
        /// <param name="errorMessage">Возвращаемое сообщение об ошибке, если результат false. если результат true,то возвращается ""</param>
        /// <param name="isreck">Обязательное ли поле</param>
        /// <returns></returns>
        public static bool Check(string type, string value, byte? length, string max, string min, bool isKey, out string errorMessage, bool isreck)
        {
            bool ok=true;
            errorMessage = "";
            if (isreck && (value == null || value=="") && (type!="Счетчик"))
            {
                errorMessage = "Поле обязательно для заполнения!";
                return false;
            }

            else
            {
                switch (type)
                {
                    case "int":
                        {
                            int x;
                            if (value != null && value != "")
                            {
                                ok = int.TryParse(value, out x);
                                if (!ok)
                                {
                                    errorMessage = "Значение должно быть целым числом!";
                                    return ok;
                                }
                                if (max != "" && max != null)
                                {
                                    int maximum = int.Parse(max);
                                    if (x > maximum)
                                    {
                                        errorMessage = "Значение должно быть меньше " + maximum;
                                        return false;
                                    }
                                }
                                if (min != "" && max != null)
                                {
                                    int minimum = int.Parse(min);
                                    if (x < minimum)
                                    {
                                        errorMessage = "Значение должно быть больше " + minimum;
                                        return false;
                                    }
                                }
                            }
                            break;
                        }
                    case "double":
                        {
                            double x;
                            if (value != null && value != "")
                            {
                                ok = double.TryParse(value, out x);
                                if (!ok)
                                {
                                    errorMessage = "Значение должно быть дробным числом!";
                                    return ok;
                                }
                                if (max != null && max != "")
                                {
                                    double maximum = double.Parse(max);
                                    if (x > maximum)
                                    {
                                        errorMessage = "Значение должно быть меньше " + maximum;
                                        return false;
                                    }
                                }
                                if (min != null && max != "")
                                {
                                    double minimum = double.Parse(min);
                                    if (x < minimum)
                                    {
                                        errorMessage = "Значение должно быть больше " + minimum;
                                        return false;
                                    }
                                }
                            }
                            break;
                        }
                    case "boolean":
                        {
                            bool x;
                            if (value != null && value != "")
                            {
                                ok = bool.TryParse(value, out x);
                                if (!ok)
                                {
                                    errorMessage = "Значение должно быть true/false!";
                                    return ok;
                                }
                            }
                            break;
                        }
                    case "DateTime":
                        {
                            DateTime x;
                            if (value != null && value != "")
                            {
                                ok = DateTime.TryParse(value, out x);
                                if (!ok)
                                {
                                    errorMessage = "Значение должно быть датой и временем!";
                                    return ok;
                                }
                                if (max != null && max!="")
                                {
                                    DateTime maximum = DateTime.Parse(max);
                                    if (x > maximum)
                                    {
                                        errorMessage = "Значение должно быть меньше " + maximum;
                                        return false;
                                    }
                                }
                                if (min != null && max != "")
                                {
                                    DateTime minimum = DateTime.Parse(min);
                                    if (x < minimum)
                                    {
                                        errorMessage = "Значение должно быть больше " + minimum;
                                        return false;
                                    }
                                }
                            }
                            break;
                        }
                    case "string":
                        {
                            if (value != null && value != "" && length != null && value.Length > length)
                            {
                                errorMessage = "Строка должна быть короче " + length;
                                return false;
                            }

                            break;
                        }
                    case "Подстановка":
                        {
                            if (value == null && value != "")
                            {
                                errorMessage = "Поле обязательно для заполнения!";
                                return false;
                            }
                            break;
                        }
                    case "Счетчик":
                        {
                            break;
                        }
                }
                
                return ok;
            }
        }
    }
}
