﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaseSystem.Model.PartialClasses
{
    /// <summary>
    /// Данный класс нужен для того, чтобы добавлять/удалять/редактировать/проверять на логичность атрибуты
    /// Кроме того, здесь есть функции для поиска элементов и полей, ссылающихся на конкретный элемент (нужны только Маше вроде)
    /// +функция, выдающая все поля данного атрибута (нужна всем возможно)
    /// изменения вносятся только Машей!
    /// </summary>
    public class PAttribute
    {
        /// <summary>
        /// Добавление атрибута. НЕ ИСПОЛЬЗОВАТЬ НИКОМУ КРОМЕ МАШИ! Перед использоватение обязательно вызывать проверку
        /// </summary>
        /// <param name="name">Название атрибута</param>
        /// <param name="type">Тип атрибута</param>
        /// <param name="isrec">Обязательный ли</param>
        /// <param name="initialValue">Начальное значение (не обязательное, можно отправить Null)</param>
        /// <param name="length">Максимальная длина (не обязательная, можно отправить Null)</param>
        /// <param name="iskey">Является ли ключом</param>
        /// <param name="max">Максимальное знаяение (не обязательное, можно отправить Null)</param>
        /// <param name="min">Минимальное значение (не обязательное, можно отправить Null)</param>
        /// <param name="t">Таблица, в котрую добавляется атрибут</param>
        /// <param name="db">Контейнер БД</param>
        public static void Add(string name, string type, bool isrec, string initialValue, byte? length, bool iskey, string max, string min, Table t, ref Model1Container db)
        {
            Attribute x = new Attribute();
            x.Table = t;
            x.AttributeName = name;
            x.AttributeType = type;
            x.InitialValue = initialValue;
            x.IsKey = iskey;
            x.IsRecuired = isrec;
            x.MaximumLength = length;
            x.MaximumValue = max;
            x.MinimumValue = min;
            db.AttributeSet.Add(x);
            List<Example> list = PTable.GetExamples(t.IDTable, ref db);
            if (list.Count > 0)
            {
                foreach (Example e in list)
                {
                    string value="";
                    if (isrec)
                    {
                        if (initialValue != "") value = initialValue;
                        else
                        {
                            if (min != "") value = min;
                            else
                            {
                                if ((type == "int") || (type == "double")) value = "0";
                                if (type == "boolean") value = "false";
                                if (type == "string") value = " ";
                                if (type == "DateTime") value = DateTime.Now.ToString();
          
                            }
                        }
                    }
                    else if (type=="Подстановка") value = "null";
                    PValues.Add(value, x, e, ref db);
                }
            }
            db.SaveChanges();
        }

        public static void Delete(Int32 id, ref Model1Container db)
        {
            if (db.AttributeSet.Find(id).AttributeType == "Подстановка")
                PConnection.Delete(db.AttributeSet.Find(id).Connection.IDConnection, ref db);
            List<Values> list = db.AttributeSet.Find(id).Values.ToList();
            foreach (Values x in list)
                PValues.Delete(x.IDValue, ref db);
            db.AttributeSet.Remove(db.AttributeSet.Find(id));
            db.SaveChanges();
        }

        /// <summary>
        /// Редактирвоани. Использовать только маше! Перед использованием вызвать проверку
        /// </summary>
        /// <param name="name">Новое имя атрибута</param>
        /// <param name="type">Новый тип атрибута</param>
        /// <param name="isrec">Обязательный ли</param>
        /// <param name="initialValue">Новое начальное значение</param>
        /// <param name="length">дмаксимальная длина (null)</param>
        /// <param name="iskey">является ли ключом</param>
        /// <param name="max">максимальное значение (null)</param>
        /// <param name="min">минимальное знаяение (null)</param>
        /// <param name="id">ID редактируемого атрибута</param>
        /// <param name="db">Контейнер БД</param>
        public static void Edit(string name, string type, bool isrec, string initialValue, byte? length, bool iskey, string max, string min, Int32 id, ref  Model1Container db)
        {
            List<Values> list = db.AttributeSet.Find(id).Values.ToList();
            foreach (Values x in list)
            {
                string s;
                if (!PValues.Check(type, x.Content, length, max, min, iskey, out s, isrec))
                    PExample.Delete(x.Example.IDExample, ref db);
            }
            db.AttributeSet.Find(id).AttributeName = name;
            db.AttributeSet.Find(id).AttributeType = type;
            db.AttributeSet.Find(id).InitialValue = initialValue;
            db.AttributeSet.Find(id).IsKey = iskey;
            db.AttributeSet.Find(id).IsRecuired = isrec;
            db.AttributeSet.Find(id).MaximumLength = length;
            db.AttributeSet.Find(id).MaximumValue = max;
            db.AttributeSet.Find(id).MinimumValue = min;
            db.SaveChanges();
        }

        /// <summary>
        /// Проверка атрибута перед добавлением/редактированием
        /// </summary>
        /// <param name="name">Название атрибута</param>
        /// <param name="type">Тип атрибута</param>
        /// <param name="isrec">Обязательный ли</param>
        /// <param name="initV">Начальное знаяение</param>
        /// <param name="length">Максимальная длина</param>
        /// <param name="iskey">Яляется ли ключом</param>
        /// <param name="max">Максимальное значение</param>
        /// <param name="min">Минимальное значение</param>
        /// <param name="errorMessage">возвращаемое сообщение об ошибке</param>
        /// <param name="t">Таблица, в которой находится атрибут</param>
        /// <param name="id">ID атрибута. Если еще не добавлен,то null</param>
        ///  <param name="db">Контейнер БД</param>
        /// <returns>Прошло ли проверку?</returns>
        public static bool Check(string name, string type, bool isrec, string initV, byte? length, bool iskey, string max, string min, out string errorMessage, Table t, Int32 id, ref Model1Container db)
        {
            if (!isrec && iskey)
            {
                errorMessage = "Ключевое поле должно быть обязательным!";
                return false;
            }
            List<Attribute> list = PTable.GetAttributes(t.IDTable, ref db);
            foreach (Attribute x in list)
            {
                if (x.AttributeName == name && x.IDAttribute != id)
                {
                    errorMessage = "В таблице уже есть атрибут с таким именем!";
                    return false;
                }
            }

            if (!CheckType(type, initV, length, iskey, max, min, out errorMessage)) return false;

            errorMessage = "";
            return true;
        }

        private static bool CheckType(string type, string initV, byte? length, bool iskey, string max, string min, out string errorMessage)
        {
            bool ok=true;
            switch (type)
            {
                case "int":
                    {
                        int x;
                        if (initV!="" && initV != null)
                        ok = int.TryParse(initV, out x);
                        if (!ok)
                        {
                            errorMessage = "Начальное значение должно быть целым числом!";
                            return ok;
                        }
                        if (length!= 0)
                        {
                            errorMessage = "Длинну можно указывать только у строкового типа!";
                            return false;
                        }
                        int maximum=0;
                        if (max != "" && max != null)
                        {                            
                            ok = int.TryParse(max, out maximum);
                            if (!ok)
                            {
                                errorMessage = "Максимальное значение должно быть целым числом! ";
                                return false;
                            }
                        }
                        int minimum=0;
                        if (min != ""&& min!= null)
                        {
                            ok = int.TryParse(min, out minimum);
                            if (!ok)
                            {
                                errorMessage = "Минимальное значение должно быть целым числом! ";
                                return false;
                            }
                        }
                        ok = int.TryParse(max, out maximum);
                        ok = int.TryParse(min, out minimum);
                        if (max != "" && min != "" && min != null && max != null && maximum < minimum)
                        {

                            errorMessage = "Минимальное значение не должно превышать максимальное! ";
                            return false;
                        }
                            break;
                    }
                case "double":
                    {
                        double x;
                        if (initV != "" && initV != null)
                            ok = double.TryParse(initV, out x);
                        if (!ok)
                        {
                            errorMessage = "Начальное значение должно быть дробным числом!";
                            return ok;
                        }
                        if (length != 0)
                        {
                            errorMessage = "Длинну можно указывать только у строкового типа!";
                            return false;
                        }
                        double maximum = 0;
                        if (max != "" && max != null)
                        {
                            ok = double.TryParse(max, out maximum);
                            if (!ok)
                            {
                                errorMessage = "Максимальное значение должно быть дробным числом! ";
                                return false;
                            }
                        }
                        double minimum = 0;
                        if (min != "" && min != null)
                        {
                            ok = double.TryParse(min, out minimum);
                            if (!ok)
                            {
                                errorMessage = "Минимальное значение должно быть дробным числом! ";
                                return false;
                            }
                        }
                        ok = double.TryParse(min, out minimum);
                        ok = double.TryParse(max, out maximum);
                        if (max != "" && min != "" && max != null && min != null && maximum < minimum)
                        {
                            errorMessage = "Минимальное значение не должно превышать максимальное! ";
                            return false;
                        }
                        break;
                    }
                case "boolean":
                    {
                        bool x;
                        if (initV!= "" && initV != null)
                        ok = bool.TryParse(initV, out x);
                        if (!ok)
                        {
                            errorMessage = "Начальное значение должно быть true/false!";
                            return ok;
                        }
                        if (length != 0)
                        {
                            errorMessage = "Длинну можно указывать только у строкового типа!";
                            return false;
                        }
                        if (max != "" && max != null)
                        {
                            errorMessage = "Максимальное значение можно указывать только у числового типа!";
                            return false;
                        }
                        if (min != "" && min != null)
                        {
                            errorMessage = "Максимальное значение можно указывать только у числового типа!";
                            return false;
                        }
                        break;
                    }
                case "DateTime":
                    {
                        DateTime x;
                        if (initV != "" && initV != null)
                            ok = DateTime.TryParse(initV, out x);
                        if (!ok)
                        {
                            errorMessage = "Начальное значение должно быть DateTime!";
                            return ok;
                        }
                        if (length != 0)
                        {
                            errorMessage = "Длинну можно указывать только у строкового типа!";
                            return false;
                        }
                        DateTime maximum = DateTime.Now;
                        if (max != "" && max != null)
                        {
                            ok = DateTime.TryParse(max, out maximum);
                            if (!ok)
                            {
                                errorMessage = "Максимальное значение должно быть DateTime! ";
                                return false;
                            }
                        }
                        DateTime minimum = DateTime.Now;
                        if (min != "" && min != null)
                        {
                            ok = DateTime.TryParse(min, out minimum);
                            if (!ok)
                            {
                                errorMessage = "Минимальное значение должно быть DateTime! ";
                                return false;
                            }
                        }
                        ok = DateTime.TryParse(max, out maximum);
                        ok = DateTime.TryParse(min, out minimum);
                        if (max != "" && min != "" && min != null && max != null && maximum < minimum)
                        {

                            errorMessage = "Минимальное значение не должно превышать максимальное! ";
                            return false;
                        }
                        break;
                    }
                case "string":
                    {
                        if (length <= 0)
                        {
                            errorMessage = "Длина должна быть больше 0!";
                            return false;
                        }

                        if (initV.Length > length)
                        {
                            errorMessage = "Начальное значение должна быть короче " + length;
                            return false;
                        }
                        if (max != "" && max != null)
                        {
                            errorMessage = "Максимальное значение можно указывать только у числового типа!";
                            return false;
                        }
                        if (min != "" && min != null)
                        {
                            errorMessage = "Максимальное значение можно указывать только у числового типа!";
                            return false;
                        }
                        break;
                    }
                case "Подстановка":
                    {
                        if (initV != "" && initV != null)
                        {
                            errorMessage = "Начальное значение нельзя указать у ссылочного типа!";
                            return false;
                        }
                        if (length != 0)
                        {
                            errorMessage = "Длинну можно указывать только у строкового типа!";
                            return false;
                        }
                        if (max != "" && max != null)
                        {
                            errorMessage = "Максимальное значение можно указывать только у числового типа!";
                            return false;
                        }
                        if (min != "" && min != null)
                        {
                            errorMessage = "Максимальное значение можно указывать только у числового типа!";
                            return false;
                        }
                        break;
                    }
                case "Счетчик":
                    {
                        if (!iskey)
                        {
                            errorMessage = "Только ключевое поле может иметь тип Счетчик!";
                            return false;
                        }
                        if (initV != "" && initV != null)
                        {
                            errorMessage = "Начальное значение нельзя указать у счетчика!";
                            return false;
                        }
                        if (length != 0)
                        {
                            errorMessage = "Длинну можно указывать только у строкового типа!";
                            return false;
                        }
                        if (max != "" && max != null)
                        {
                            errorMessage = "Максимальное значение можно указывать только у числового типа!";
                            return false;
                        }
                        if (min != "" && min != null)
                        {
                            errorMessage = "Максимальное значение можно указывать только у числового типа!";
                            return false;
                        }
                        break;
                    }
                default:
                    {
                        errorMessage = "Недопустимый тип!";
                        return false;
                    }
            }
            errorMessage = "";
            return true;
        }

        /// <summary>
        /// Выдает значения всех полей данного атрбута. Скорее всего нужна всем.
        /// </summary>
        /// <param name="id">ID атрибута</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Все значения данного атрибута (все конкретные марки машин)</returns>
        public static List<Values> GetValues(Int32 id, ref Model1Container db)
        {
            List<Values> list = (from x in db.ValuesSet where x.Attribute.IDAttribute == id select x).ToList();
            return list;
        }

        /// <summary>
        /// Выдает список всех объектов, которые с помощью данного атрибута ссылаются на данный объект
        /// Нужен Маше
        /// </summary>
        /// <param name="id">ID атрибута (который ссылается) (ID пользователя машиной)</param>
        /// <param name="keyValue">Значение ключа объекта, на который ссылаются (человек)</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Список объектов (машин)</returns>
        public static List<Example> GetAllReferenceObjects(Int32 id, string keyValue, ref Model1Container db)
        {
            List<Example> answer = new List<Example>();
            List<Values> list = GetValues(id, ref db);
            foreach (Values x in list)
            {
                if (x.Content == keyValue)
                {
                    answer.Add(x.Example);
                }
            }
            return answer;
        }

        /// <summary>
        /// Выдает список всех полей, которые с помощью данного атрибута ссылаются на данный объект
        /// Не знаю, зачем он понадобится кому-то, кроме Маши
        /// </summary>
        /// <param name="id">ID атрибута (который ссылается) (ID пользователя машиной)</param>
        /// <param name="keyValue">Значение ключа объекта, на который ссылаются (человек)</param>
        /// <param name="db">Контейнер БД</param>
        /// <returns>Список полей (ID пользователей конкретных машин)</returns>
        public static List<Values> GetAllReferenceValues(Int32 id, string keyValue, ref Model1Container db)
        {
            List<Values> answer = new List<Values>();
            List<Values> list = GetValues(id, ref db);
            foreach (Values x in list)
            {
                if (x.Content == keyValue)
                {
                    answer.Add(x);
                }
            }
            return answer;
        }
    }
}
