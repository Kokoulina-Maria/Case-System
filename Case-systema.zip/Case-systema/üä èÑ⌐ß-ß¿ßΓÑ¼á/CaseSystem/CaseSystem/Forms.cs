﻿using CaseSystem.Model;
using CaseSystem.Model.PartialClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CaseSystem
{
    public partial class Forms : Form
    {
        Model1Container db;
        Table table;
        List<Model.Attribute> attributes;
        List<Example> examples;
        int indexCurExample;

        public Forms(Table _table, ref Model1Container _db)
        {
            InitializeComponent();
            db = _db;
            table = _table;
            attributes = (from a in db.AttributeSet where (a.Table.IDTable == table.IDTable) select a).ToList();
            examples = (from a in db.ExampleSet where (a.Table.IDTable == table.IDTable) select a).ToList();
            indexCurExample = -1;
            this.Text = table.TableName;
        }

        private void Forms_Load(object sender, EventArgs e)
        {
            int X = 50;
            int Y = 50;
            foreach (Model.Attribute x in attributes)
            {
                Label label = new Label();
                label.Top = Y;
                label.Left = X;
                label.Width = 160;
                label.Text = x.AttributeName;
                this.Controls.Add(label);
                X += 160 + 50;

                if (x.AttributeType != "Подстановка")
                {
                    TextBox textBox = new TextBox();
                    textBox.Top = Y;
                    textBox.Left = X;
                    textBox.Width = 250;
                    if (x.AttributeType == "Счетчик")
                        textBox.Enabled = false;
                    this.Controls.Add(textBox);
                }
                else
                {
                    ComboBox comboBox = new ComboBox();
                    comboBox.Top = Y;
                    comboBox.Left = X;
                    comboBox.Width = 250;
                    foreach (Example y in (from a in db.ExampleSet where (a.Table.IDTable == x.Connection.Table.IDTable) select a).ToList())
                        comboBox.Items.Add(PExample.GetKeyValue(y.IDExample, ref db));
                    this.Controls.Add(comboBox);
                }
                Y += 30;
                X -= 160 + 50;
            }

            Button addButton = new Button();
            addButton.Top = Y;
            addButton.Left = X;
            addButton.Width = 120;
            addButton.Text = "Добавить";
            addButton.Click += new EventHandler(Add);
            this.Controls.Add(addButton);
            Button editButton = new Button();
            editButton.Top = Y;
            editButton.Left = 2 * X + 120;
            editButton.Width = 120;
            editButton.Text = "Изменить";
            editButton.Click += new EventHandler(Edit);
            this.Controls.Add(editButton);
            Button deleteButton = new Button();
            deleteButton.Top = Y;
            deleteButton.Left = 3 * X + 120 * 2; ;
            deleteButton.Width = 120;
            deleteButton.Text = "Удалить";
            deleteButton.Click += new EventHandler(Delete);
            this.Controls.Add(deleteButton);
            Y += 30;
            this.Width = 3 * 120 + 4 * X;

            Button leftButton = new Button();
            leftButton.Top = Y;
            leftButton.Left = this.Width / 2 - 125;
            leftButton.Width = 50;
            leftButton.Text = "<";
            leftButton.Click += new EventHandler(ToTheLeft);
            this.Controls.Add(leftButton);
            Label labelForIndex = new Label();
            labelForIndex.Top = Y;
            labelForIndex.Left = this.Width / 2 - 25;
            labelForIndex.Width = 50;
            labelForIndex.TextAlign = ContentAlignment.MiddleCenter;
            labelForIndex.Text = indexCurExample.ToString();
            this.Controls.Add(labelForIndex);
            Button rightButton = new Button();
            rightButton.Top = Y;
            rightButton.Left = this.Width / 2 + 75;
            rightButton.Width = 50;
            rightButton.Text = ">";
            rightButton.Click += new EventHandler(ToTheRight);
            this.Controls.Add(rightButton);
            Y += 100;

            this.Height = Y;
            ToTheRight(sender, e);
        }

        private void ToTheLeft(object sender, EventArgs e)
        {
            indexCurExample--;
            int indexCurAttribute = 0;

            if (indexCurExample < 0)
            {
                if (indexCurExample < -1)
                    indexCurExample++;

                foreach (Control x in this.Controls)
                {
                    if (x is TextBox)
                    {
                        x.Text = attributes[indexCurAttribute].InitialValue;
                        indexCurAttribute++;
                    }
                    if (x is ComboBox)
                    {
                        Model.Attribute curAttribute = attributes[indexCurAttribute];
                        foreach (Example y in (from a in db.ExampleSet
                                               where

                                               (a.Table.IDTable == curAttribute.Connection.Table.IDTable)
                                               select a).ToList())
                            ((ComboBox)x).Items.Add(PExample.GetKeyValue(y.IDExample, ref db));
                        ((ComboBox)x).SelectedItem = 0;
                        indexCurAttribute++;
                    }
                    else if (x is Label && x.Text == (indexCurExample - 1).ToString())
                        x.Text = examples.Count.ToString();
                }
            }
            else
            {
                Example curExample = examples[indexCurExample];
                foreach (Control x in this.Controls)
                {
                    if (x is TextBox)
                    {
                        Model.Attribute curAttribute = attributes[indexCurAttribute];
                        x.Text = (from a in db.ValuesSet
                                  where ((a.Example.IDExample == curExample.IDExample) && (a.Attribute.IDAttribute == curAttribute.IDAttribute))
                                  select a).ToList().First().Content;
                        indexCurAttribute++;
                    }
                    else if (x is ComboBox)
                    {
                        Model.Attribute curAttribute = attributes[indexCurAttribute];
                        foreach (Example y in (from a in db.ExampleSet
                                               where (a.Table.IDTable == curAttribute.Connection.Table.IDTable)
                                               select a).ToList())
                            ((ComboBox)x).Items.Add(PExample.GetKeyValue(y.IDExample, ref db));
                        x.Text = x.Text = (from a in db.ValuesSet
                                           where ((a.Example.IDExample == curExample.IDExample) && (a.Attribute.IDAttribute == curAttribute.IDAttribute))
                                           select a).ToList().First().Content;
                        indexCurAttribute++;
                    }
                    else if (x is Label && x.Text == (indexCurExample + 1).ToString())
                        x.Text = indexCurExample.ToString();
                }
            }
        }

        private void ToTheRight(object sender, EventArgs e)
        {
            indexCurExample++;
            int indexCurAttribute = 0;

            if (indexCurExample > examples.Count - 1)
            {
                if (indexCurExample > examples.Count)
                    indexCurExample--;

                foreach (Control x in this.Controls)
                {
                    if (x is TextBox)
                    {
                        x.Text = attributes[indexCurAttribute].InitialValue;
                        indexCurAttribute++;
                    }
                    if (x is ComboBox)
                    {
                        Model.Attribute curAttribute = attributes[indexCurAttribute];
                        ((ComboBox)x).Items.Clear();
                        foreach (Example y in (from a in db.ExampleSet
                                               where (a.Table.IDTable == curAttribute.Connection.Table.IDTable)
                                               select a).ToList())
                            ((ComboBox)x).Items.Add(PExample.GetKeyValue(y.IDExample, ref db));
                        ((ComboBox)x).SelectedItem = 0;
                        indexCurAttribute++;
                    }
                    else if (x is Label && x.Text == (indexCurExample - 1).ToString())
                        x.Text = indexCurExample.ToString();
                }
            }
            else
            {
                Example curExample = examples[indexCurExample];
                foreach (Control x in this.Controls)
                {
                    if (x is TextBox)
                    {
                        Model.Attribute curAttribute = attributes[indexCurAttribute];
                        x.Text = (from a in db.ValuesSet
                                  where ((a.Example.IDExample == curExample.IDExample) && (a.Attribute.IDAttribute == curAttribute.IDAttribute))
                                  select a).ToList().First().Content;
                        indexCurAttribute++;
                    }
                    else if (x is ComboBox)
                    {
                        Model.Attribute curAttribute = attributes[indexCurAttribute];
                        ((ComboBox)x).Items.Clear();
                        foreach (Example y in (from a in db.ExampleSet
                                               where (a.Table.IDTable == curAttribute.Connection.Table.IDTable)
                                               select a).ToList())
                            ((ComboBox)x).Items.Add(PExample.GetKeyValue(y.IDExample, ref db));
                        x.Text = x.Text = (from a in db.ValuesSet
                                           where ((a.Example.IDExample == curExample.IDExample) && (a.Attribute.IDAttribute == curAttribute.IDAttribute))
                                           select a).ToList().First().Content;
                        indexCurAttribute++;
                    }
                    else if (x is Label && x.Text == (indexCurExample - 1).ToString())
                        x.Text = indexCurExample.ToString();
                }
            }
        }

        private void Add(object sender, EventArgs e)
        {
            try
            {
                if (indexCurExample != examples.Count)
                {
                    indexCurExample = examples.Count;
                    ToTheRight(sender, e);
                }
                else
                {
                    //получаем список значений 
                    List<Model.Values> list = GetValues();
                    string message;
                    if (!PExample.Add(list, table, out message, ref db))
                        MessageBox.Show(message);
                    examples = (from a in db.ExampleSet where (a.Table.IDTable == table.IDTable) select a).ToList();
                }
            }
            catch(Exception q)
            {

            }
        }

        private List<Model.Values> GetValues()
        {
            int indexCurAttribute = 0;
            List<Model.Values> list = new List<Model.Values>();
            foreach (Control x in this.Controls)
            {
                if (x is TextBox)
                {
                    Model.Attribute curAttribute = attributes[indexCurAttribute];
                    string value = ((TextBox)x).Text;
                    Values v = new Values
                    {
                        Content = value,
                        Attribute = curAttribute,
                    };
                    list.Add(v);
                    indexCurAttribute++;
                }
                else if (x is ComboBox)
                {
                    Model.Attribute curAttribute = attributes[indexCurAttribute];
                    string value = ((ComboBox)x).Text;
                    Values v = new Values
                    {
                        Content = value,
                        Attribute = curAttribute,
                    };
                    list.Add(v);
                    indexCurAttribute++;
                }
            }
            return list;
        }

        private void Delete(object sender, EventArgs e)
        {
            try
            {
                Example x = examples[indexCurExample];
                if (!PExample.Delete(x.IDExample, ref db))
                    MessageBox.Show("На данный объект существует ссылка с жесткой связью. Перед тем, как удалить данный объект, удалите все ссылающиеся на него элементы с жесткой связью!");
                examples = (from a in db.ExampleSet where (a.Table.IDTable == table.IDTable) select a).ToList();
            }
            catch (Exception q)
            {

            }
        }

        private void Edit(object sender, EventArgs e)
        {
            try
            {
                List<Model.Values> list = GetValues();
                int indexCurAttribute = 0;
                Example ex = examples[indexCurExample];
                //получаем список ключевых полей 
                string keys = "";
                foreach (Control x in this.Controls)
                {
                    if (x is TextBox)
                    {
                        if (attributes[indexCurAttribute].IsKey)
                            keys = keys + ((TextBox)x).Text;
                        indexCurAttribute++;
                    }
                    else if (x is ComboBox)
                    {
                        if (attributes[indexCurAttribute].IsKey)
                            keys = keys + ((ComboBox)x).Text;
                        indexCurAttribute++;
                    }
                }
                if (PExample.CheckID(keys, ref db, ex))
                {
                    string m;
                    if (!PExample.Change(ex.IDExample, list, out m, ref db))
                        MessageBox.Show(m);
                }
                else MessageBox.Show("Элемент с таким ключом существует");
                examples = (from a in db.ExampleSet where (a.Table.IDTable == table.IDTable) select a).ToList();
            }
            catch(Exception q)
            {

            }
        }
    }
}
