﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using CaseSystem.MetamodelForms;
using CaseSystem.Model;
using CaseSystem.Model.PartialClasses;


namespace CaseSystem
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Model1Container db = new Model1Container();
            if (db.ProjectSet.Count() == 0) PProject.Add("TestProject", ref db);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
